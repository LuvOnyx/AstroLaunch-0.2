// Core domain types for AstroLaunch (v3 — Phase 2)

export interface FileNode {
  id: string
  name: string
  path: string
  type: "file" | "folder"
  parentId: string | null
  children?: string[]
  content?: string
  language?: string
  size?: number
  modified?: number
  agentTouched?: 0 | 1
  baseline?: string
}

export interface AgentChat {
  id: string
  name: string
  agentId: string
  createdAt: number
  updatedAt: number
  pinned?: 0 | 1
  archived?: 0 | 1
  totalCostUsd?: number
  totalTokens?: number
  /** Optional parent chat id when this chat is a fork. */
  parentChatId?: string
  /** Source message id this chat was forked from. */
  forkedFromMessageId?: string
  /** Color tag for visual grouping in the sidebar. */
  color?: string
}

/** v3: a sub-chat inside a chat (1code-style tabs). */
export interface SubChat {
  id: string
  chatId: string
  title: string
  createdAt: number
  updatedAt: number
  pinned?: 0 | 1
  /** Order in the tab strip. */
  order?: number
  /** Optional persona override for this sub-chat. */
  personaId?: string
}

export type AgentMessageRole = "user" | "assistant" | "system" | "tool"

export interface AgentMessage {
  id: string
  chatId: string
  /** v3: optional sub-chat scope. Messages with no subChatId belong to the chat root. */
  subChatId?: string
  role: AgentMessageRole
  content: string
  toolCalls?: ToolCall[]
  taskId?: string
  createdAt: number
  toolDiffs?: ToolDiff[]
  usage?: TokenUsage
  personaId?: string
  /** Plan structure attached to a system message during plan mode. */
  plan?: PlanStepView[]
  /** File mentions parsed from the user message. */
  mentions?: string[]
  /** Mark a message as the head of a fork branch. */
  forkPoint?: 0 | 1
}

export interface PlanStepView {
  title: string
  description: string
  doneCriteria: string
  approved?: boolean
}

export interface ToolCall {
  id: string
  name: string
  args: Record<string, unknown>
  result?: unknown
  status: "pending" | "running" | "success" | "error"
  retries?: number
  durationMs?: number
}

export interface ToolDiff {
  tool: string
  path: string
  kind: "create" | "update" | "delete"
  before?: string
  after?: string
  unified?: string
  added?: number
  removed?: number
}

export interface TokenUsage {
  input: number
  output: number
  total: number
  costUsd: number
  model: string
}

export interface AgentTask {
  id: string
  chatId: string
  parentTaskId?: string
  title: string
  description: string
  status: "pending" | "in_progress" | "blocked" | "completed" | "failed"
  is_done: boolean
  doneCriteria: string
  evidence?: string
  createdAt: number
  updatedAt: number
  iterations: number
  maxIterations: number
  artifacts?: string[]
  toolHistory?: { name: string; ok: boolean; ts: number }[]
  retries?: number
}

export interface AgentPersona {
  id: string
  name: string
  emoji: string
  description: string
  systemPrompt: string
  defaultModel: string
  color: string
}

export interface ProjectMeta {
  id: string
  name: string
  rootPath: string
  createdAt: number
  framework?: "next" | "vite" | "react" | "node" | "static"
  hasGit: boolean
}

/** v3: a queued prompt waiting for the agent to be free. */
export interface QueuedMessage {
  id: string
  chatId: string
  subChatId?: string
  content: string
  mentions?: string[]
  createdAt: number
  /** When non-null, the queued item is locked and being sent. */
  sendingAt?: number
}

/* ---------- v0.2 / v0.3 additions ---------- */

export interface PluginRecord {
  id: string
  name: string
  version: string
  description: string
  author?: string
  entry: string
  permissions: PluginPermission[]
  contributes: PluginContribution[]
  enabled: boolean
  installedAt: number
  storage?: Record<string, unknown>
  source?: { manifest: string; code: string }
}

export type PluginPermission =
  | "read_files" | "write_files" | "run_commands" | "open_dialogs"
  | "agent_calls" | "preview_url" | "settings"

export interface PluginContribution {
  surface: "panel" | "command" | "statusbar" | "toolbar" | "editor_action"
  title: string
  icon?: string
  commandId?: string
  view?: string
}

export interface PluginEvent { type: string; payload?: unknown }

export interface TerminalSession {
  id: string
  title: string
  cwd: string
  createdAt: number
  buffer?: string
}

export interface UsageRow {
  id: string
  chatId: string
  taskId?: string
  model: string
  input: number
  output: number
  costUsd: number
  ts: number
}

/** v3: design tokens captured from Penpot or the fallback canvas. */
export interface DesignToken {
  id: string
  name: string
  value: string
  /** color | spacing | radius | font | shadow | other */
  kind: string
  /** group/page in the design file. */
  group?: string
  source: "penpot" | "fallback" | "manual"
  updatedAt: number
}

/** v3: a design frame extracted from Penpot for "design → code" flows. */
export interface DesignFrame {
  id: string
  name: string
  /** SVG payload exported from Penpot. */
  svg?: string
  /** Generated React/HTML code, if any. */
  code?: string
  width?: number
  height?: number
  capturedAt: number
}
