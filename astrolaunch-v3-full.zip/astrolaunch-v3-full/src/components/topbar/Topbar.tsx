"use client"
/**
 * Topbar — v3 polish.
 *
 * Two-pill design ↔ preview switch wired to the new `designMode` workspace
 * field, glassy gradient logo, refined spacing and a more legible cost chip.
 * The legacy three-mode toggle (preview/canvas/split) is preserved for
 * keyboard-shortcut compat but routed to the new mode under the hood.
 */
import { motion } from "framer-motion"
import { AppIcon } from "@/lib/iconify"
import { Button } from "@/components/ui/button"
import { useWorkspace } from "@/store/workspace"
import { useSettings } from "@/store/settings"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"
import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import { useEffect, useState } from "react"
import { db } from "@/lib/storage/db"

interface TopbarProps {
  onOpenSettings: () => void
  onRunPreview: () => void
  isRunning: boolean
  onOpenCommandPalette: () => void
}

export function Topbar({ onOpenSettings, onRunPreview, isRunning, onOpenCommandPalette }: TopbarProps) {
  const {
    designMode, setDesignMode, showRightChat, setShowRightChat,
    showLeftSidebar, setShowLeftSidebar, showBottomPanel, setShowBottomPanel,
    setBottomTab, activePluginId, setActivePluginId,
  } = useWorkspace()
  const { apiKeys, defaultModel } = useSettings()
  const [chatCost, setChatCost] = useState(0)

  useEffect(() => {
    const tick = async () => {
      if (!db) return
      const total = await db.chats.toArray().then((cs) => cs.reduce((s, c) => s + (c.totalCostUsd ?? 0), 0))
      setChatCost(total)
    }
    tick()
    const t = setInterval(tick, 4000)
    return () => clearInterval(t)
  }, [])

  return (
    <motion.header
      initial={{ y: -16, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.25 }}
      className="h-11 flex items-center justify-between px-3 border-b border-border bg-gradient-to-r from-al-topbar via-al-topbar to-al-panel/80 text-foreground select-none"
    >
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 px-1">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-violet-500 via-fuchsia-500 to-cyan-400 flex items-center justify-center text-[12px] font-bold text-white shadow-lg shadow-violet-500/25 ring-1 ring-white/10">
            ⌁
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-sm font-semibold tracking-tight">AstroLaunch</span>
            <span className="text-[10px] text-muted-foreground border border-border rounded px-1 py-0.5 font-mono">v0.3</span>
          </div>
        </div>
        <div className="h-5 w-px bg-border" />
        <nav className="flex items-center gap-0.5 text-xs text-muted-foreground">
          <Tooltip><TooltipTrigger asChild>
            <button onClick={() => setShowLeftSidebar(!showLeftSidebar)} className="hover:text-foreground px-2 py-1 rounded hover:bg-accent/40 transition">
              <AppIcon name="layout" width={13} />
            </button>
          </TooltipTrigger><TooltipContent>Toggle sidebar (⌘B)</TooltipContent></Tooltip>
          <Tooltip><TooltipTrigger asChild>
            <button onClick={() => { setShowBottomPanel(!showBottomPanel); setBottomTab("terminal") }} className="hover:text-foreground px-2 py-1 rounded hover:bg-accent/40 transition">
              <AppIcon name="terminal" width={13} />
            </button>
          </TooltipTrigger><TooltipContent>Toggle terminal (⌘`)</TooltipContent></Tooltip>
          <Tooltip><TooltipTrigger asChild>
            <button onClick={onOpenCommandPalette} className="hover:text-foreground px-2 py-1 rounded hover:bg-accent/40 transition">
              <AppIcon name="search" width={13} />
            </button>
          </TooltipTrigger><TooltipContent>Command palette (⌘K)</TooltipContent></Tooltip>
        </nav>
      </div>

      {/* Design ↔ Preview pill switch */}
      <div className="flex items-center gap-1.5 bg-al-panel/80 rounded-md p-0.5 border border-border ring-1 ring-white/5 backdrop-blur">
        {(["preview", "design"] as const).map((m) => (
          <Tooltip key={m}>
            <TooltipTrigger asChild>
              <button
                onClick={() => { setDesignMode(m); setActivePluginId(null) }}
                className={cn(
                  "px-3 py-1 rounded text-xs font-medium transition flex items-center gap-1.5 relative",
                  designMode === m && !activePluginId
                    ? "bg-gradient-to-r from-al-accent/30 to-al-accent/15 text-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                <AppIcon name={m === "preview" ? "preview" : "canvas"} width={14} />
                {m.charAt(0).toUpperCase() + m.slice(1)}
              </button>
            </TooltipTrigger>
            <TooltipContent>{m === "design" ? "Penpot / Fast Canvas" : "Live preview"}</TooltipContent>
          </Tooltip>
        ))}
        {activePluginId && (
          <button className="px-3 py-1 rounded text-xs font-medium flex items-center gap-1.5 bg-al-accent/25 text-foreground">
            <AppIcon name="puzzle" width={14} /> Plugin
          </button>
        )}
      </div>

      <div className="flex items-center gap-2">
        {chatCost > 0 && (
          <Badge variant="outline" className="text-[10px] py-0 px-1.5 font-mono">
            ${chatCost.toFixed(3)}
          </Badge>
        )}
        <Badge variant={apiKeys.gemini ? "success" : "warning"} className="text-[10px]">
          {apiKeys.gemini ? defaultModel.replace("gemini-", "") : "no key"}
        </Badge>
        <Button
          size="sm"
          variant={isRunning ? "secondary" : "default"}
          onClick={onRunPreview}
          className={cn(isRunning ? "" : "shadow shadow-al-accent/20")}
        >
          <AppIcon name={isRunning ? "stop" : "play"} width={14} />
          {isRunning ? "Stop" : "Run"}
        </Button>
        <Tooltip><TooltipTrigger asChild>
          <Button size="icon-sm" variant="ghost" onClick={() => setShowRightChat(!showRightChat)}>
            <AppIcon name="chat" width={16} />
          </Button>
        </TooltipTrigger><TooltipContent>Toggle agent chat (⌘J)</TooltipContent></Tooltip>
        <Tooltip><TooltipTrigger asChild>
          <Button size="icon-sm" variant="ghost" onClick={onOpenSettings}>
            <AppIcon name="settings" width={16} />
          </Button>
        </TooltipTrigger><TooltipContent>Settings (⌘,)</TooltipContent></Tooltip>
      </div>
    </motion.header>
  )
}
