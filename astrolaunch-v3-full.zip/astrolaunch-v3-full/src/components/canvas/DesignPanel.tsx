"use client"
/**
 * DesignPanel — top-level wrapper that owns the design surface.
 *
 *  - Picks Penpot when a connection is configured, falls back to the
 *    in-house FallbackCanvas otherwise.
 *  - Listens for `astrolaunch:penpot-config` to switch surfaces live.
 *  - Provides the design ↔ preview swap button used by the new layout.
 */
import { useEffect, useState } from "react"
import { PenpotCanvas } from "./PenpotCanvas"
import { FallbackCanvas } from "./FallbackCanvas"

const STORAGE = "astrolaunch.penpot.config.v3"

export function DesignPanel() {
  const [hasPenpot, setHasPenpot] = useState<boolean>(() => {
    if (typeof window === "undefined") return false
    try {
      const cfg = JSON.parse(localStorage.getItem(STORAGE) ?? "{}")
      return Boolean(cfg?.fileId)
    } catch { return false }
  })

  useEffect(() => {
    const onCfg = (e: Event) => {
      const detail = (e as CustomEvent).detail as { fileId?: string } | undefined
      setHasPenpot(Boolean(detail?.fileId))
    }
    window.addEventListener("astrolaunch:penpot-config", onCfg)
    return () => window.removeEventListener("astrolaunch:penpot-config", onCfg)
  }, [])

  return hasPenpot ? <PenpotCanvas /> : <FallbackCanvas />
}
