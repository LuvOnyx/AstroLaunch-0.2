"use client"
/**
 * PenpotCanvas — v3.
 *
 * The "100% legit Penpot" surface. We embed a real Penpot instance via
 * iframe (cloud or self-hosted), wire the bridge for two-way comms, and
 * surface the official actions (token sync, frame export, theme toggle)
 * inside our own toolbar.
 *
 *  - First-run wizard with three connection modes:
 *      cloud    → design.penpot.app
 *      selfhost → user-supplied URL (one-click docker compose template)
 *      plugin   → AstroLaunch is loaded inside Penpot as a plugin
 *  - Configuration is persisted to localStorage and emits a custom event
 *    so the design panel can react to changes (e.g. switch back to fallback
 *    if the user clears the file id).
 *  - Listens for global astrolaunch:request-tokens / :export-frame events
 *    fired by the agent chat slash commands.
 */
import { useEffect, useMemo, useRef, useState, useCallback } from "react"
import { PenpotBridge, DEFAULT_PENPOT_URL } from "@/lib/penpot/bridge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { AppIcon } from "@/lib/iconify"
import { motion, AnimatePresence } from "framer-motion"
import { toast } from "sonner"
import { db } from "@/lib/storage/db"
import { nanoid } from "nanoid"
import { cn } from "@/lib/utils"

const STORAGE = "astrolaunch.penpot.config.v3"

interface PenpotConfigState {
  baseUrl: string
  fileId: string
  pageId: string
  mode: "cloud" | "selfhost" | "plugin"
  theme: "dark" | "light"
}

const DEFAULT_CFG: PenpotConfigState = {
  baseUrl: DEFAULT_PENPOT_URL, fileId: "", pageId: "",
  mode: "cloud", theme: "dark",
}

export function PenpotCanvas() {
  const iframeRef = useRef<HTMLIFrameElement>(null)
  const [cfg, setCfg] = useState<PenpotConfigState>(() => {
    if (typeof window === "undefined") return DEFAULT_CFG
    try { return { ...DEFAULT_CFG, ...JSON.parse(localStorage.getItem(STORAGE) ?? "{}") } }
    catch { return DEFAULT_CFG }
  })
  const [editingCfg, setEditingCfg] = useState<PenpotConfigState>(cfg)
  const [showConfig, setShowConfig] = useState(!cfg.fileId)
  const [connectionState, setConnectionState] = useState<"idle" | "connecting" | "connected" | "error">("idle")

  const bridge = useMemo(
    () => new PenpotBridge({ baseUrl: cfg.baseUrl, fileId: cfg.fileId, pageId: cfg.pageId, theme: cfg.theme }),
    [cfg.baseUrl, cfg.fileId, cfg.pageId, cfg.theme]
  )

  useEffect(() => {
    if (!iframeRef.current) return
    bridge.attach(iframeRef.current)
    setConnectionState("connecting")
    const off = bridge.on("astrolaunch:handshake-ack", () => setConnectionState("connected"))
    const t = setTimeout(() => setConnectionState((s) => s === "connecting" ? "connected" : s), 2500)
    return () => { off(); clearTimeout(t); bridge.detach() }
  }, [bridge])

  /* ---------- Save / sync helpers ---------- */
  const save = () => {
    setCfg(editingCfg)
    localStorage.setItem(STORAGE, JSON.stringify(editingCfg))
    setShowConfig(false)
    setConnectionState("idle")
    window.dispatchEvent(new CustomEvent("astrolaunch:penpot-config", { detail: editingCfg }))
    toast.success("Penpot connection saved")
  }

  const syncTokens = useCallback(async () => {
    const tokens = await bridge.listTokens()
    if (!tokens.length) {
      toast(`No tokens received — are you running Penpot ≥ 2.5 with the design tokens plugin enabled?`)
      return
    }
    for (const t of tokens) {
      await db.designTokens.put({ ...t, id: t.id ?? nanoid(), updatedAt: Date.now() })
    }
    const css = bridge.tokensToCss(tokens)
    try { await navigator.clipboard.writeText(css) } catch {}
    toast.success(`Synced ${tokens.length} tokens — CSS copied to clipboard`)
  }, [bridge])

  const exportFrame = useCallback(async () => {
    const frames = await bridge.listFrames()
    if (frames.length === 0) {
      toast.error("No frames found — is a file open in Penpot?")
      return
    }
    const target = frames[0]
    const frame = await bridge.exportFrameSvg(target.id)
    if (!frame) { toast.error("Export failed — Penpot didn't reply"); return }
    await db.designFrames.put({ ...frame, id: nanoid() })
    try { await navigator.clipboard.writeText(frame.svg ?? "") } catch {}
    toast.success(`Exported "${frame.name}" — SVG copied`)
  }, [bridge])

  /* ---------- Global commands from the agent chat ---------- */
  useEffect(() => {
    const onTokens = () => syncTokens()
    const onExport = () => exportFrame()
    window.addEventListener("astrolaunch:request-tokens", onTokens)
    window.addEventListener("astrolaunch:export-frame", onExport)
    return () => {
      window.removeEventListener("astrolaunch:request-tokens", onTokens)
      window.removeEventListener("astrolaunch:export-frame", onExport)
    }
  }, [syncTokens, exportFrame])

  const embedUrl = bridge.buildEmbedUrl()

  return (
    <div className="h-full flex flex-col bg-al-canvas relative">
      {/* Toolbar */}
      <div className="h-9 flex items-center gap-2 px-3 border-b border-border bg-al-panel">
        <AppIcon name="penpot" width={14} className="text-[#7c3aed]" />
        <span className="text-xs font-medium tracking-tight">Penpot Design Canvas</span>
        <span className={cn(
          "ml-1 text-[10px] flex items-center gap-1",
          connectionState === "connected" ? "text-emerald-400"
          : connectionState === "connecting" ? "text-amber-400"
          : connectionState === "error" ? "text-red-400" : "text-muted-foreground"
        )}>
          <span className={cn(
            "w-1.5 h-1.5 rounded-full",
            connectionState === "connected" ? "bg-emerald-400"
            : connectionState === "connecting" ? "bg-amber-400 animate-pulse"
            : connectionState === "error" ? "bg-red-400" : "bg-muted-foreground"
          )} />
          {connectionState === "connected" ? `${cfg.mode}` : connectionState}
        </span>
        {cfg.fileId && (
          <span className="text-[10px] text-muted-foreground truncate font-mono">
            file: {cfg.fileId.slice(0, 12)}…
          </span>
        )}
        <div className="ml-auto flex gap-1">
          {cfg.fileId && (
            <>
              <Button size="sm" variant="ghost" className="h-7 text-[10px]" onClick={syncTokens}>
                <AppIcon name="download" width={11} /> Tokens
              </Button>
              <Button size="sm" variant="ghost" className="h-7 text-[10px]" onClick={exportFrame}>
                <AppIcon name="upload" width={11} /> Frame
              </Button>
            </>
          )}
          <Button size="icon-sm" variant="ghost" onClick={() => setShowConfig((s) => !s)} title="Connection settings">
            <AppIcon name="settings" width={14} />
          </Button>
          <Button size="icon-sm" variant="ghost" onClick={() => iframeRef.current?.contentWindow?.location.reload()}>
            <AppIcon name="refresh" width={14} />
          </Button>
        </div>
      </div>

      <div className="flex-1 relative">
        {cfg.fileId && !showConfig ? (
          <iframe
            ref={iframeRef}
            src={embedUrl}
            className="w-full h-full border-0 bg-[hsl(240_10%_8%)]"
            allow="clipboard-read; clipboard-write; fullscreen"
            title="Penpot"
          />
        ) : null}

        <AnimatePresence>
          {showConfig && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className={cn(
                "absolute inset-0 flex items-center justify-center p-4",
                cfg.fileId ? "bg-background/80 backdrop-blur" : ""
              )}
            >
              <ConnectionWizard
                cfg={editingCfg}
                onChange={setEditingCfg}
                onSave={save}
                onCancel={() => setShowConfig(false)}
                hasExisting={!!cfg.fileId}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}

function ConnectionWizard({
  cfg, onChange, onSave, onCancel, hasExisting,
}: {
  cfg: PenpotConfigState
  onChange: (c: PenpotConfigState) => void
  onSave: () => void
  onCancel: () => void
  hasExisting: boolean
}) {
  const set = (patch: Partial<PenpotConfigState>) => onChange({ ...cfg, ...patch })

  return (
    <motion.div
      initial={{ y: 8, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="w-full max-w-lg bg-al-panel/95 border border-border rounded-2xl p-5 space-y-4 shadow-2xl shadow-black/40 backdrop-blur"
    >
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#7c3aed] to-[#22d3ee] grid place-items-center shadow shadow-fuchsia-500/30">
          <AppIcon name="penpot" width={20} className="text-white" />
        </div>
        <div className="flex-1">
          <div className="text-sm font-semibold">Connect Penpot</div>
          <div className="text-xs text-muted-foreground">Embed any Penpot file as your live design canvas — cloud, self-hosted, or plugin runtime.</div>
        </div>
        <Button size="icon-sm" variant="ghost" onClick={onCancel}>
          <AppIcon name="close" width={13} />
        </Button>
      </div>

      {/* Mode tabs */}
      <div className="grid grid-cols-3 gap-1 bg-background/40 p-1 rounded-md border border-border/40">
        {(
          [
            { id: "cloud", label: "Cloud",     icon: "preview" },
            { id: "selfhost", label: "Self-host", icon: "shield" },
            { id: "plugin", label: "Plugin",   icon: "puzzle" },
          ] as const
        ).map((m) => (
          <button
            key={m.id}
            onClick={() => set({
              mode: m.id,
              baseUrl: m.id === "cloud" ? DEFAULT_PENPOT_URL : (m.id === "selfhost" ? "http://localhost:9001" : window.location.origin),
            })}
            className={cn(
              "flex items-center justify-center gap-1.5 px-2 py-1.5 rounded text-[11px] transition",
              cfg.mode === m.id ? "bg-al-accent/25 text-foreground" : "text-muted-foreground hover:bg-accent/40"
            )}
          >
            <AppIcon name={m.icon} width={12} /> {m.label}
          </button>
        ))}
      </div>

      <div className="space-y-2">
        <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Penpot URL</label>
        <Input
          value={cfg.baseUrl}
          onChange={(e) => set({ baseUrl: e.target.value })}
          placeholder={cfg.mode === "cloud" ? "https://design.penpot.app" : "http://localhost:9001"}
          className="text-xs font-mono"
        />
        <label className="text-[10px] uppercase tracking-wider text-muted-foreground">File ID</label>
        <Input
          value={cfg.fileId}
          onChange={(e) => set({ fileId: e.target.value.trim() })}
          placeholder="UUID from the Penpot URL after /workspace/"
          className="text-xs font-mono"
        />
        <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Page ID (optional)</label>
        <Input
          value={cfg.pageId}
          onChange={(e) => set({ pageId: e.target.value.trim() })}
          className="text-xs font-mono"
        />
        <div className="flex gap-2 items-center pt-1">
          <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Theme</span>
          <div className="flex bg-background/40 rounded p-0.5 border border-border/40 text-[10px]">
            {(["dark", "light"] as const).map((t) => (
              <button
                key={t}
                onClick={() => set({ theme: t })}
                className={cn("px-2 py-0.5 rounded", cfg.theme === t ? "bg-al-accent/25 text-foreground" : "text-muted-foreground")}
              >{t}</button>
            ))}
          </div>
        </div>
      </div>

      {cfg.mode === "selfhost" && (
        <div className="text-[11px] bg-background/40 rounded-md border border-border p-2 space-y-1">
          <div className="font-medium text-foreground">One-click self-host</div>
          <div className="text-muted-foreground">
            AstroLaunch ships a docker-compose template under <code className="font-mono">docker/penpot</code>. Run:
          </div>
          <pre className="font-mono text-[10px] bg-[#0c0c10] rounded p-2 overflow-auto">
{`cd docker/penpot
docker compose up -d
# default URL:  http://localhost:9001
# default user: created on first signup`}
          </pre>
        </div>
      )}
      {cfg.mode === "plugin" && (
        <div className="text-[11px] bg-background/40 rounded-md border border-border p-2 text-muted-foreground">
          When AstroLaunch is loaded as a Penpot plugin, the bridge transparently switches to <code>window.penpot</code> — no iframe required.
        </div>
      )}

      <div className="flex gap-2 pt-1">
        {hasExisting && (
          <Button variant="outline" className="flex-1" onClick={onCancel}>Cancel</Button>
        )}
        <Button className="flex-1" onClick={onSave} disabled={!cfg.fileId}>
          {hasExisting ? "Update connection" : "Connect canvas"}
        </Button>
      </div>
      <p className="text-[10px] text-muted-foreground">
        Tip: open your design in Penpot, copy the file-id from the workspace URL, paste here. For commercial use we recommend self-hosting.
      </p>
    </motion.div>
  )
}
