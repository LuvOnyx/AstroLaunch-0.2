"use client"
/**
 * FallbackCanvas — used when no Penpot connection is available.
 *
 * A pragmatic SVG-based design surface that supports the minimum useful subset
 * needed to feel like a "Figma-lite" pane:
 *
 *   - Tools: select, rectangle, ellipse, text, frame, pen
 *   - Move + 8-handle resize for the active selection
 *   - Properties inspector (fill, stroke, radius, rotation, font size)
 *   - Z-order, duplicate, delete via inspector and keyboard
 *   - Persisted to IndexedDB through the workspace store
 *   - Export → SVG (saved as `DesignFrame`)
 *
 * The component is intentionally kept self-contained — no external libs are
 * required and a swap to a richer engine (e.g. tldraw) is a one-line change
 * inside DesignPanel.tsx.
 */
import { useEffect, useMemo, useRef, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { AppIcon } from "@/lib/iconify"
import { cn } from "@/lib/utils"
import { type CanvasDoc, type CanvasShape, DEFAULT_DOC, makeShape, exportSvg, frameFromDoc } from "@/lib/canvas/fallback"
import { motion } from "framer-motion"
import { toast } from "sonner"

const STORAGE_KEY = "astrolaunch.fallback-canvas.doc.v1"

type Tool = "select" | "rect" | "ellipse" | "text" | "frame" | "pen"

export function FallbackCanvas() {
  const [doc, setDoc] = useState<CanvasDoc>(() => {
    if (typeof window === "undefined") return DEFAULT_DOC
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "") || DEFAULT_DOC }
    catch { return DEFAULT_DOC }
  })
  const [tool, setTool] = useState<Tool>("select")
  const [selected, setSelected] = useState<string | null>(null)
  const [drawing, setDrawing] = useState<{ id: string; ox: number; oy: number } | null>(null)
  const [drag, setDrag] = useState<{ id: string; ox: number; oy: number; sx: number; sy: number } | null>(null)
  const [resize, setResize] = useState<{ id: string; handle: string; ox: number; oy: number; orig: CanvasShape } | null>(null)
  const svgRef = useRef<SVGSVGElement>(null)

  // persist
  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(doc)) } catch {}
  }, [doc])

  const sel = useMemo(() => doc.shapes.find((s) => s.id === selected) ?? null, [doc.shapes, selected])

  const update = useCallback((id: string, patch: Partial<CanvasShape>) => {
    setDoc((d) => ({ ...d, shapes: d.shapes.map((s) => s.id === id ? { ...s, ...patch } : s), updatedAt: Date.now() }))
  }, [])

  const addShape = (kind: CanvasShape["kind"], x: number, y: number) => {
    const z = (doc.shapes.reduce((mx, s) => Math.max(mx, s.z ?? 0), 0)) + 1
    const s = makeShape({
      kind, x, y, w: kind === "text" ? 200 : 160, h: kind === "text" ? 32 : 100, z,
      fill: kind === "frame" ? "transparent" : "#a78bfa",
      stroke: kind === "frame" ? "#a78bfa" : "transparent",
      strokeWidth: kind === "frame" ? 1 : 0,
      text: kind === "text" ? "Heading" : undefined,
      fontSize: kind === "text" ? 24 : 16,
    })
    setDoc((d) => ({ ...d, shapes: [...d.shapes, s], updatedAt: Date.now() }))
    return s
  }

  const remove = (id: string) => {
    setDoc((d) => ({ ...d, shapes: d.shapes.filter((s) => s.id !== id), updatedAt: Date.now() }))
    setSelected((cur) => (cur === id ? null : cur))
  }

  const duplicate = (id: string) => {
    const src = doc.shapes.find((s) => s.id === id); if (!src) return
    const n: CanvasShape = { ...src, id: Math.random().toString(36).slice(2, 9), x: src.x + 16, y: src.y + 16, z: (src.z ?? 0) + 1 }
    setDoc((d) => ({ ...d, shapes: [...d.shapes, n], updatedAt: Date.now() }))
    setSelected(n.id)
  }

  // svg coords from event
  const xy = (e: React.PointerEvent | React.MouseEvent) => {
    const r = svgRef.current?.getBoundingClientRect()
    if (!r) return { x: 0, y: 0 }
    const sx = doc.width / r.width, sy = doc.height / r.height
    return { x: (e.clientX - r.left) * sx, y: (e.clientY - r.top) * sy }
  }

  // pointer handlers
  const onCanvasDown = (e: React.PointerEvent) => {
    if ((e.target as Element).closest("[data-shape]")) return
    const { x, y } = xy(e)
    if (tool === "select") { setSelected(null); return }
    if (tool === "pen") return // pen handled differently
    const s = addShape(tool === "rect" ? "rect" : tool === "ellipse" ? "ellipse" : tool === "frame" ? "frame" : "text", x, y)
    setSelected(s.id)
    setDrawing({ id: s.id, ox: x, oy: y })
  }
  const onCanvasMove = (e: React.PointerEvent) => {
    const { x, y } = xy(e)
    if (drawing) {
      update(drawing.id, {
        x: Math.min(drawing.ox, x), y: Math.min(drawing.oy, y),
        w: Math.max(8, Math.abs(x - drawing.ox)), h: Math.max(8, Math.abs(y - drawing.oy)),
      })
    } else if (drag) {
      update(drag.id, { x: drag.sx + (x - drag.ox), y: drag.sy + (y - drag.oy) })
    } else if (resize) {
      const o = resize.orig, dx = x - resize.ox, dy = y - resize.oy
      const next: Partial<CanvasShape> = {}
      if (resize.handle.includes("e")) next.w = Math.max(8, o.w + dx)
      if (resize.handle.includes("s")) next.h = Math.max(8, o.h + dy)
      if (resize.handle.includes("w")) { next.x = o.x + dx; next.w = Math.max(8, o.w - dx) }
      if (resize.handle.includes("n")) { next.y = o.y + dy; next.h = Math.max(8, o.h - dy) }
      update(resize.id, next)
    }
  }
  const onCanvasUp = () => {
    setDrawing(null); setDrag(null); setResize(null)
    if (drawing && tool !== "select") setTool("select")
  }

  const onShapeDown = (e: React.PointerEvent, id: string) => {
    e.stopPropagation()
    setSelected(id)
    if (tool !== "select") return
    const s = doc.shapes.find((x) => x.id === id); if (!s) return
    const { x, y } = xy(e)
    setDrag({ id, ox: x, oy: y, sx: s.x, sy: s.y })
  }
  const onHandleDown = (e: React.PointerEvent, handle: string) => {
    e.stopPropagation()
    if (!sel) return
    const { x, y } = xy(e)
    setResize({ id: sel.id, handle, ox: x, oy: y, orig: { ...sel } })
  }

  // keyboard
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.closest("input, textarea")) return
      if (!selected) return
      if (e.key === "Delete" || e.key === "Backspace") { e.preventDefault(); remove(selected) }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "d") { e.preventDefault(); duplicate(selected) }
      if (sel) {
        const step = e.shiftKey ? 10 : 1
        if (e.key === "ArrowLeft") update(sel.id, { x: sel.x - step })
        if (e.key === "ArrowRight") update(sel.id, { x: sel.x + step })
        if (e.key === "ArrowUp") update(sel.id, { y: sel.y - step })
        if (e.key === "ArrowDown") update(sel.id, { y: sel.y + step })
      }
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [selected, sel, update])

  const exportFrame = async () => {
    const svg = exportSvg(doc)
    const frame = frameFromDoc(doc)
    try {
      // Stash in localStorage as "last frame" so the design panel can attach it to chat
      localStorage.setItem("astrolaunch.fallback.last-frame", JSON.stringify(frame))
      await navigator.clipboard.writeText(svg)
      toast.success("SVG copied to clipboard & last-frame saved")
    } catch { toast.error("Export failed") }
  }

  return (
    <div className="h-full flex flex-col bg-al-canvas">
      {/* Toolbar */}
      <div className="h-9 flex items-center gap-2 px-3 border-b border-border bg-al-panel">
        <span className="text-xs font-medium tracking-tight text-foreground/90 flex items-center gap-1.5">
          <AppIcon name="canvas" width={13} className="text-fuchsia-400" />
          Fast Canvas
          <span className="text-[10px] text-muted-foreground">— offline fallback</span>
        </span>
        <div className="ml-2 flex items-center gap-0.5 bg-background/40 rounded p-0.5 border border-border/40">
          {(
            [
              { id: "select", icon: "drag", title: "Select (V)" },
              { id: "rect",   icon: "layout", title: "Rectangle" },
              { id: "ellipse",icon: "preview", title: "Ellipse" },
              { id: "frame",  icon: "puzzle", title: "Frame" },
              { id: "text",   icon: "edit", title: "Text" },
            ] as { id: Tool; icon: string; title: string }[]
          ).map((t) => (
            <button
              key={t.id}
              title={t.title}
              onClick={() => setTool(t.id)}
              className={cn(
                "h-6 w-6 grid place-items-center rounded transition",
                tool === t.id ? "bg-al-accent/30 text-foreground" : "text-muted-foreground hover:bg-accent/40"
              )}
            >
              <AppIcon name={t.icon} width={12} />
            </button>
          ))}
        </div>
        <div className="ml-auto flex items-center gap-1">
          <Button size="sm" variant="ghost" className="h-7 text-[10px]" onClick={exportFrame}>
            <AppIcon name="upload" width={11} /> Export
          </Button>
        </div>
      </div>

      {/* Canvas + inspector */}
      <div className="flex-1 flex min-h-0">
        <div className="flex-1 overflow-auto bg-[radial-gradient(circle_at_50%_30%,hsl(240_6%_18%),hsl(240_10%_8%))] p-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mx-auto shadow-2xl shadow-black/50 ring-1 ring-white/5"
            style={{ width: doc.width, maxWidth: "100%" }}
          >
            <svg
              ref={svgRef}
              viewBox={`0 0 ${doc.width} ${doc.height}`}
              className="block w-full h-auto bg-[hsl(240_10%_6%)]"
              onPointerDown={onCanvasDown}
              onPointerMove={onCanvasMove}
              onPointerUp={onCanvasUp}
              onPointerLeave={onCanvasUp}
            >
              <rect width={doc.width} height={doc.height} fill={doc.background} />
              {[...doc.shapes].sort((a, b) => (a.z ?? 0) - (b.z ?? 0)).map((s) => (
                <ShapeNode key={s.id} shape={s} selected={s.id === selected} onPointerDown={(e) => onShapeDown(e, s.id)} />
              ))}
              {sel && <ResizeHandles shape={sel} onHandleDown={onHandleDown} />}
            </svg>
          </motion.div>
        </div>
        <Inspector
          doc={doc}
          sel={sel}
          onUpdate={update}
          onRemove={remove}
          onDuplicate={duplicate}
          onDocPatch={(patch) => setDoc((d) => ({ ...d, ...patch, updatedAt: Date.now() }))}
        />
      </div>
    </div>
  )
}

function ShapeNode({ shape: s, selected, onPointerDown }: { shape: CanvasShape; selected: boolean; onPointerDown: (e: React.PointerEvent) => void }) {
  const tx = s.rotation ? `rotate(${s.rotation} ${s.x + s.w / 2} ${s.y + s.h / 2})` : undefined
  const ringStroke = selected ? "url(#al-sel-ring)" : (s.stroke ?? "transparent")
  const common = {
    "data-shape": "true" as const,
    onPointerDown,
    transform: tx,
    style: { cursor: "move" as const },
  }
  return (
    <>
      <defs>
        <linearGradient id="al-sel-ring" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#a78bfa" />
          <stop offset="100%" stopColor="#22d3ee" />
        </linearGradient>
      </defs>
      {s.kind === "rect" || s.kind === "frame" ? (
        <rect
          {...common}
          x={s.x} y={s.y} width={s.w} height={s.h}
          rx={s.radius ?? 0}
          fill={s.fill ?? "transparent"}
          stroke={selected ? ringStroke : (s.stroke ?? "transparent")}
          strokeWidth={selected ? 1.5 : (s.strokeWidth ?? 0)}
          strokeDasharray={s.kind === "frame" && !selected ? "4 4" : undefined}
        />
      ) : s.kind === "ellipse" ? (
        <ellipse
          {...common}
          cx={s.x + s.w / 2} cy={s.y + s.h / 2} rx={s.w / 2} ry={s.h / 2}
          fill={s.fill ?? "transparent"}
          stroke={selected ? ringStroke : (s.stroke ?? "transparent")}
          strokeWidth={selected ? 1.5 : (s.strokeWidth ?? 0)}
        />
      ) : s.kind === "text" ? (
        <text
          {...common}
          x={s.x} y={s.y + (s.fontSize ?? 16)}
          fontFamily={s.fontFamily ?? "Inter, sans-serif"}
          fontSize={s.fontSize ?? 16}
          fill={s.fill ?? "#fff"}
        >{s.text ?? ""}</text>
      ) : null}
    </>
  )
}

function ResizeHandles({ shape: s, onHandleDown }: { shape: CanvasShape; onHandleDown: (e: React.PointerEvent, handle: string) => void }) {
  const handles = [
    ["nw", s.x, s.y], ["n", s.x + s.w / 2, s.y], ["ne", s.x + s.w, s.y],
    ["w", s.x, s.y + s.h / 2], ["e", s.x + s.w, s.y + s.h / 2],
    ["sw", s.x, s.y + s.h], ["s", s.x + s.w / 2, s.y + s.h], ["se", s.x + s.w, s.y + s.h],
  ] as const
  return (
    <>
      <rect x={s.x} y={s.y} width={s.w} height={s.h} fill="none" stroke="#a78bfa" strokeWidth={0.75} strokeDasharray="4 3" pointerEvents="none" />
      {handles.map(([name, cx, cy]) => (
        <rect
          key={String(name)}
          x={(cx as number) - 4} y={(cy as number) - 4} width={8} height={8}
          fill="#0c0c10" stroke="#a78bfa" strokeWidth={1.2}
          style={{ cursor: `${name}-resize` as React.CSSProperties["cursor"] }}
          onPointerDown={(e) => onHandleDown(e, name as string)}
        />
      ))}
    </>
  )
}

function Inspector({
  doc, sel, onUpdate, onRemove, onDuplicate, onDocPatch,
}: {
  doc: CanvasDoc
  sel: CanvasShape | null
  onUpdate: (id: string, patch: Partial<CanvasShape>) => void
  onRemove: (id: string) => void
  onDuplicate: (id: string) => void
  onDocPatch: (patch: Partial<CanvasDoc>) => void
}) {
  return (
    <div className="w-56 border-l border-border bg-al-panel/70 overflow-auto p-2 space-y-3 text-[11px]">
      {sel ? (
        <>
          <div className="text-muted-foreground uppercase text-[10px] tracking-wider">{sel.kind}</div>
          <Row label="Position">
            <NumInput value={sel.x} onChange={(n) => onUpdate(sel.id, { x: n })} suffix="x" />
            <NumInput value={sel.y} onChange={(n) => onUpdate(sel.id, { y: n })} suffix="y" />
          </Row>
          <Row label="Size">
            <NumInput value={sel.w} onChange={(n) => onUpdate(sel.id, { w: n })} suffix="w" />
            <NumInput value={sel.h} onChange={(n) => onUpdate(sel.id, { h: n })} suffix="h" />
          </Row>
          {(sel.kind === "rect" || sel.kind === "frame") && (
            <Row label="Radius">
              <NumInput value={sel.radius ?? 0} onChange={(n) => onUpdate(sel.id, { radius: n })} />
            </Row>
          )}
          <Row label="Rotation">
            <NumInput value={sel.rotation ?? 0} onChange={(n) => onUpdate(sel.id, { rotation: n })} suffix="°" />
          </Row>
          {sel.kind !== "text" ? (
            <>
              <ColorRow label="Fill" value={sel.fill ?? "#000"} onChange={(c) => onUpdate(sel.id, { fill: c })} />
              <ColorRow label="Stroke" value={sel.stroke ?? "#000"} onChange={(c) => onUpdate(sel.id, { stroke: c })} />
              <Row label="Stroke W">
                <NumInput value={sel.strokeWidth ?? 0} onChange={(n) => onUpdate(sel.id, { strokeWidth: n })} />
              </Row>
            </>
          ) : (
            <>
              <Row label="Text">
                <Input value={sel.text ?? ""} onChange={(e) => onUpdate(sel.id, { text: e.target.value })} className="h-6 text-[11px]" />
              </Row>
              <Row label="Font size">
                <NumInput value={sel.fontSize ?? 16} onChange={(n) => onUpdate(sel.id, { fontSize: n })} />
              </Row>
              <ColorRow label="Color" value={sel.fill ?? "#fff"} onChange={(c) => onUpdate(sel.id, { fill: c })} />
            </>
          )}
          <div className="flex gap-1 pt-2 border-t border-border">
            <Button size="sm" variant="outline" className="flex-1 h-7 text-[10px]" onClick={() => onDuplicate(sel.id)}>
              <AppIcon name="copy" width={10} /> Duplicate
            </Button>
            <Button size="sm" variant="outline" className="flex-1 h-7 text-[10px]" onClick={() => onRemove(sel.id)}>
              <AppIcon name="trash" width={10} /> Delete
            </Button>
          </div>
        </>
      ) : (
        <>
          <div className="text-muted-foreground uppercase text-[10px] tracking-wider">Document</div>
          <Row label="Size">
            <NumInput value={doc.width}  onChange={(n) => onDocPatch({ width: n })} suffix="w" />
            <NumInput value={doc.height} onChange={(n) => onDocPatch({ height: n })} suffix="h" />
          </Row>
          <ColorRow label="Background" value={doc.background} onChange={(c) => onDocPatch({ background: c })} />
          <div className="text-[10px] text-muted-foreground pt-2">
            Pick a tool, click & drag on the canvas to draw. Click a shape to inspect.
          </div>
        </>
      )}
    </div>
  )
}
function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-0.5">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="flex gap-1">{children}</div>
    </div>
  )
}
function NumInput({ value, onChange, suffix }: { value: number; onChange: (n: number) => void; suffix?: string }) {
  return (
    <div className="flex-1 relative">
      <input
        type="number"
        value={Math.round(value)}
        onChange={(e) => onChange(Number(e.target.value) || 0)}
        className="w-full h-6 bg-background/70 border border-border rounded px-1.5 text-[11px] outline-none focus:border-al-accent/60"
      />
      {suffix && <span className="absolute right-1 top-1 text-[9px] text-muted-foreground pointer-events-none">{suffix}</span>}
    </div>
  )
}
function ColorRow({ label, value, onChange }: { label: string; value: string; onChange: (c: string) => void }) {
  return (
    <div className="space-y-0.5">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="flex gap-1 items-center">
        <input
          type="color"
          value={hexish(value)}
          onChange={(e) => onChange(e.target.value)}
          className="w-7 h-6 rounded border border-border bg-transparent cursor-pointer"
        />
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1 h-6 bg-background/70 border border-border rounded px-1.5 text-[11px] outline-none focus:border-al-accent/60 font-mono"
        />
      </div>
    </div>
  )
}
function hexish(s: string) { return /^#[0-9a-f]{6}$/i.test(s) ? s : "#a78bfa" }
