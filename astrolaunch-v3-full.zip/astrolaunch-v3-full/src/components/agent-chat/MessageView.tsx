"use client"
/**
 * Single chat message rendering — v3.
 *
 *  - assistant streaming with shimmering cursor
 *  - tool diffs with status / retries / duration
 *  - per-message usage badge
 *  - inline action toolbar (copy, fork, rollback) on hover, 1code-style
 *  - file mention rendering (@path → clickable badge)
 */
import type { AgentMessage } from "@/types"
import { cn } from "@/lib/utils"
import { AppIcon, FileIcon } from "@/lib/iconify"
import { Badge } from "@/components/ui/badge"
import { useWorkspace } from "@/store/workspace"
import { useState } from "react"
import { DEFAULT_PERSONAS } from "@/lib/agents/personas"
import { db } from "@/lib/storage/db"
import { toast } from "sonner"
import { nanoid } from "nanoid"

interface Props {
  message: AgentMessage
  streaming?: boolean
  showDiffs?: boolean
  onFork?: (msg: AgentMessage) => void
  onRollback?: (msg: AgentMessage) => void
}

export function MessageView({ message: m, streaming, showDiffs = true, onFork, onRollback }: Props) {
  const { setDiffViewer } = useWorkspace()
  const persona = m.personaId ? DEFAULT_PERSONAS.find((p) => p.id === m.personaId) : null
  const [copied, setCopied] = useState(false)

  const copy = async () => {
    try { await navigator.clipboard.writeText(m.content); setCopied(true); setTimeout(() => setCopied(false), 1200) }
    catch { toast.error("Copy failed") }
  }

  if (m.role === "tool") {
    const tc = m.toolCalls?.[0]
    return (
      <div className="space-y-1">
        <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
          <span className={cn(
            "w-1.5 h-1.5 rounded-full",
            tc?.status === "success" ? "bg-emerald-400" :
            tc?.status === "error" ? "bg-red-400" :
            "bg-amber-400 animate-pulse"
          )} />
          <code className="bg-background/50 px-1 rounded">{tc?.name}</code>
          <span className="opacity-60">→ {tc?.status}</span>
          {!!tc?.retries && <Badge variant="outline" className="text-[9px] py-0 px-1">retries: {tc.retries}</Badge>}
          {!!tc?.durationMs && <span className="opacity-60">{tc.durationMs}ms</span>}
        </div>
        {showDiffs && m.toolDiffs?.map((d, i) => (
          <button
            key={i}
            onClick={() => setDiffViewer(true, d.path)}
            className="block w-full text-left rounded border border-border bg-background/40 p-2 hover:bg-background/70 transition"
          >
            <div className="flex items-center gap-2 text-[11px]">
              <span className={cn(
                "px-1 rounded text-[9px] font-medium",
                d.kind === "create" && "bg-emerald-500/20 text-emerald-300",
                d.kind === "update" && "bg-amber-500/20 text-amber-300",
                d.kind === "delete" && "bg-red-500/20 text-red-300",
              )}>{d.kind}</span>
              <span className="font-mono truncate flex-1">{d.path}</span>
              <span className="text-emerald-400">+{d.added ?? 0}</span>
              <span className="text-red-400">-{d.removed ?? 0}</span>
            </div>
            {d.unified && <UnifiedSnippet text={d.unified} />}
          </button>
        ))}
      </div>
    )
  }

  if (m.role === "system") {
    return (
      <div className="text-[11px] italic text-muted-foreground border-l-2 border-al-accent/40 pl-2 py-0.5">
        {m.content}
      </div>
    )
  }

  return (
    <div className={cn("group flex gap-2", m.role === "user" && "justify-end")}>
      {m.role !== "user" && (
        <div
          className="w-6 h-6 rounded-md flex items-center justify-center text-xs flex-shrink-0 ring-1 ring-border"
          style={{ background: persona ? `${persona.color}33` : "hsl(var(--al-accent) / 0.2)" }}
          title={persona?.name ?? "Assistant"}
        >
          {persona?.emoji ?? "⌁"}
        </div>
      )}
      <div className={cn(
        "rounded-lg px-3 py-2 max-w-[85%] whitespace-pre-wrap break-words text-[13px] leading-relaxed relative",
        m.role === "user"
          ? "bg-gradient-to-br from-al-accent/25 to-al-accent/15 text-foreground"
          : "bg-background/50 border border-border"
      )}>
        <RenderContent content={m.content} streaming={streaming} mentions={m.mentions} />
        {m.usage && (
          <div className="mt-1.5 flex items-center gap-2 text-[10px] text-muted-foreground border-t border-border/40 pt-1">
            <span>{m.usage.input}↑ {m.usage.output}↓ tok</span>
            <span>· ${m.usage.costUsd.toFixed(4)}</span>
            <span className="opacity-60">· {m.usage.model}</span>
          </div>
        )}

        {/* hover toolbar */}
        <div className={cn(
          "absolute -top-3 right-1 opacity-0 group-hover:opacity-100 transition flex items-center gap-0.5 rounded-md border border-border bg-al-panel/95 backdrop-blur px-1 py-0.5 shadow",
        )}>
          <button onClick={copy} title="Copy" className="p-1 hover:text-foreground text-muted-foreground">
            <AppIcon name={copied ? "check" : "copy"} width={11} />
          </button>
          {m.role === "assistant" && onFork && (
            <button onClick={() => onFork(m)} title="Fork from here" className="p-1 hover:text-foreground text-muted-foreground">
              <AppIcon name="diff" width={11} />
            </button>
          )}
          {m.role === "user" && onRollback && (
            <button onClick={() => onRollback(m)} title="Rollback to this message" className="p-1 hover:text-foreground text-muted-foreground">
              <AppIcon name="refresh" width={11} />
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

function RenderContent({ content, streaming, mentions }: { content: string; streaming?: boolean; mentions?: string[] }) {
  if (!content) return streaming ? <span className="opacity-60 animate-pulse">…</span> : null
  // Highlight mentions inline
  const parts: (string | { mention: string })[] = []
  let last = 0
  const re = /@([^\s@]+)/g
  let match: RegExpExecArray | null
  while ((match = re.exec(content)) !== null) {
    if (match.index > last) parts.push(content.slice(last, match.index))
    parts.push({ mention: match[1] })
    last = match.index + match[0].length
  }
  if (last < content.length) parts.push(content.slice(last))
  return (
    <>
      {parts.map((p, i) =>
        typeof p === "string"
          ? <span key={i}>{p}</span>
          : <span key={i} className="inline-flex items-center gap-1 px-1 rounded bg-al-accent/20 text-al-accent text-[11px] font-mono mx-0.5">
              <FileIcon filename={p.mention.split("/").pop() ?? p.mention} width={10} />
              {p.mention}
            </span>
      )}
      {streaming && <span className="inline-block w-1.5 h-3 ml-0.5 bg-al-accent animate-pulse rounded-sm align-middle" />}
      {mentions && mentions.length > 0 && (
        <div className="mt-1 flex flex-wrap gap-1">
          {mentions.map((m) => (
            <span key={m} className="inline-flex items-center gap-1 px-1 rounded bg-background/60 border border-border text-[10px] font-mono">
              <FileIcon filename={m.split("/").pop() ?? m} width={9} /> {m}
            </span>
          ))}
        </div>
      )}
    </>
  )
}

function UnifiedSnippet({ text }: { text: string }) {
  const [open, setOpen] = useState(false)
  const lines = text.split("\n").slice(0, 30)
  return (
    <div className="mt-1">
      <button onClick={(e) => { e.stopPropagation(); setOpen(!open) }} className="text-[10px] text-muted-foreground hover:text-foreground">
        {open ? "▼" : "▶"} {open ? "hide diff" : "show diff"}
      </button>
      {open && (
        <pre className="mt-1 font-mono text-[10px] leading-4 max-h-48 overflow-auto bg-[#0c0c10] rounded p-2">
          {lines.map((l, i) => (
            <div key={i} className={cn(
              l.startsWith("+") && !l.startsWith("+++") && "text-emerald-400",
              l.startsWith("-") && !l.startsWith("---") && "text-red-400",
              l.startsWith("@@") && "text-cyan-400",
            )}>{l}</div>
          ))}
          {text.split("\n").length > 30 && <div className="opacity-60">… (truncated)</div>}
        </pre>
      )}
    </div>
  )
}

/** Helper used by the FloatingAgentChat to actually fork a chat at a message. */
export async function forkChatAtMessage(srcMsg: AgentMessage): Promise<string | null> {
  const src = await db.chats.get(srcMsg.chatId)
  if (!src) return null
  const newId = nanoid()
  await db.chats.add({
    id: newId,
    name: `${src.name} ↗ fork`,
    agentId: src.agentId,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    parentChatId: src.id,
    forkedFromMessageId: srcMsg.id,
  })
  // copy messages up to and including the source message
  const all = await db.messages.where("chatId").equals(src.id).sortBy("createdAt")
  const idx = all.findIndex((m) => m.id === srcMsg.id)
  const slice = idx >= 0 ? all.slice(0, idx + 1) : all
  for (const m of slice) {
    await db.messages.add({ ...m, id: nanoid(), chatId: newId, subChatId: undefined })
  }
  return newId
}
