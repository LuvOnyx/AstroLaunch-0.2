"use client"
/**
 * FloatingAgentChat — v3.
 *
 * Brings the 21st-dev/1code-style agent chat surface into AstroLaunch:
 *
 *  - Sub-chat tab strip (per-chat tabs, drag-reorder, pinning)
 *  - Slash-command palette (/plan, /build, /agent, /fork, /clear, /run,
 *    /design, /tokens, /export, /rollback)
 *  - File mentions (@path) with fuzzy picker
 *  - Plan mode card (clarify → approve → run)
 *  - Message queue (drains automatically when the agent goes idle)
 *  - Per-message action toolbar (copy, fork, rollback)
 *  - Glassy floating window with smooth motion + minimize bubble
 *  - SSE streaming, tool diffs, accumulated cost meter, abort button
 */
import { useState, useRef, useEffect, useCallback, useMemo } from "react"
import { motion, useDragControls, AnimatePresence } from "framer-motion"
import { useWorkspace } from "@/store/workspace"
import { useSettings } from "@/store/settings"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { AppIcon } from "@/lib/iconify"
import { db } from "@/lib/storage/db"
import { nanoid } from "nanoid"
import { orchestrator, approxUsage } from "@/lib/agents/orchestrator"
import { cn } from "@/lib/utils"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { DEFAULT_PERSONAS } from "@/lib/agents/personas"
import type { AgentMessage, AgentTask, PlanStepView, QueuedMessage } from "@/types"
import { MessageView, forkChatAtMessage } from "./MessageView"
import { estimateCost, priceFor } from "@/lib/agents/pricing"
import { toast } from "sonner"
import { SubChatTabs } from "./sub/SubChatTabs"
import { MessageQueue } from "./sub/MessageQueue"
import { PlanCard } from "./sub/PlanCard"
import { FileMentionPicker } from "./sub/FileMentionPicker"
import { SlashCommandPalette, SLASH_COMMANDS, type SlashCommand } from "./sub/SlashCommandPalette"

export function FloatingAgentChat() {
  const {
    showRightChat, agentChatPosition, setAgentChatPosition,
    agentChatSize, setAgentChatSize, activeChatId, setActiveChatId,
    activeSubChatId, setActiveSubChatId, agentChatMinimized, setAgentChatMinimized,
    setDesignMode, toggleDesignMode, setBottomTab,
  } = useWorkspace()
  const { defaultModel, set, apiKeys, showToolDiffs, costCapUsd } = useSettings()
  const dragControls = useDragControls()
  const containerRef = useRef<HTMLDivElement>(null)
  const messagesRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  const [messages, setMessages] = useState<AgentMessage[]>([])
  const [tasks, setTasks] = useState<AgentTask[]>([])
  const [input, setInput] = useState("")
  const [streaming, setStreaming] = useState(false)
  const [building, setBuilding] = useState(false)
  const [logs, setLogs] = useState<string[]>([])
  const [tab, setTab] = useState<"chat" | "tasks" | "stats">("chat")
  const [chatName, setChatName] = useState<string>("New Chat")
  const [persona, setPersona] = useState<string>("builder")
  const [accumulatedCost, setAccumulatedCost] = useState(0)
  const [accumulatedTokens, setAccumulatedTokens] = useState(0)
  const [pendingPlan, setPendingPlan] = useState<{ goal: string; steps: PlanStepView[] } | null>(null)
  const [showSlash, setShowSlash] = useState(false)
  const [showMention, setShowMention] = useState(false)
  const [mentionQuery, setMentionQuery] = useState("")
  const [slashQuery, setSlashQuery] = useState("")
  const abortStreamRef = useRef<AbortController | null>(null)

  // ── Load chat + sub-chat scope ──────────────────────────────────────────
  useEffect(() => {
    (async () => {
      if (!db) return
      let id = activeChatId
      if (!id) {
        const allChats = await db.chats.orderBy("updatedAt").reverse().toArray()
        const existing = allChats.find((c) => c.archived !== 1)
        if (existing) { id = existing.id; setActiveChatId(id) }
        else {
          id = nanoid()
          await db.chats.add({ id, name: "New Chat", agentId: "builder", createdAt: Date.now(), updatedAt: Date.now() })
          setActiveChatId(id)
        }
      }
      const all = await db.messages.where("chatId").equals(id!).sortBy("createdAt")
      const scoped = activeSubChatId
        ? all.filter((m) => m.subChatId === activeSubChatId)
        : all.filter((m) => !m.subChatId)
      setMessages(scoped)
      const ts = await db.tasks.where("chatId").equals(id!).toArray()
      setTasks(ts)
      const meta = await db.chats.get(id!)
      if (meta) {
        setChatName(meta.name)
        setPersona(meta.agentId)
        setAccumulatedCost(meta.totalCostUsd ?? 0)
        setAccumulatedTokens(meta.totalTokens ?? 0)
      }
    })()
  }, [activeChatId, activeSubChatId, setActiveChatId])

  // ── Subscribe to orchestrator events ────────────────────────────────────
  useEffect(() => {
    return orchestrator.on(async (e) => {
      const line = `${e.type}: ${typeof e.payload === "string" ? e.payload : JSON.stringify(e.payload).slice(0, 220)}`
      setLogs((l) => [...l.slice(-300), line])
      try { window.dispatchEvent(new CustomEvent("astrolaunch:agent-log", { detail: line })) } catch {}
      if (activeChatId && (e.type === "plan" || e.type === "task_done" || e.type === "task_start" || e.type === "task_failed")) {
        const ts = await db.tasks.where("chatId").equals(activeChatId).toArray()
        setTasks(ts)
      }
      if (e.type === "message" && activeChatId) {
        const all = await db.messages.where("chatId").equals(activeChatId).sortBy("createdAt")
        const scoped = activeSubChatId
          ? all.filter((m) => m.subChatId === activeSubChatId)
          : all.filter((m) => !m.subChatId)
        setMessages(scoped)
      }
      if (e.type === "usage") {
        const u = e.payload as { costUsd: number; input: number; output: number; accumulated: number }
        setAccumulatedCost(u.accumulated)
        setAccumulatedTokens((prev) => prev + u.input + u.output)
      }
      if (e.type === "cost_cap_hit") {
        const u = e.payload as { spent: number; cap: number }
        toast.warning(`Cost cap hit: $${u.spent.toFixed(3)} ≥ $${u.cap.toFixed(2)}. Run paused.`)
      }
      if (e.type === "stop") {
        setBuilding(false)
        const r = e.payload as { reason?: string }
        if (r.reason === "all_done") toast.success("All tasks completed ✨")
        else if (r.reason === "user_aborted") toast("Run aborted")
      }
    })
  }, [activeChatId, activeSubChatId])

  useEffect(() => {
    messagesRef.current?.scrollTo({ top: 99999, behavior: "smooth" })
  }, [messages, streaming])

  const abortAll = useCallback(() => {
    abortStreamRef.current?.abort()
    orchestrator.abort()
  }, [])

  // ── Input parsers ───────────────────────────────────────────────────────
  useEffect(() => {
    const trimmed = input.trimStart()
    if (trimmed.startsWith("/")) {
      // detect first token
      const firstTok = trimmed.split(/\s/)[0]
      setShowSlash(firstTok.length <= 12 && !trimmed.includes(" "))
      setSlashQuery(firstTok)
    } else {
      setShowSlash(false)
    }
    // mentions: last word starts with @
    const lastSpace = input.lastIndexOf(" ")
    const tail = input.slice(lastSpace + 1)
    if (tail.startsWith("@") && tail.length >= 1) {
      setShowMention(true)
      setMentionQuery(tail)
    } else {
      setShowMention(false)
    }
  }, [input])

  const parseMentions = (text: string): string[] => {
    const re = /@([^\s@]+)/g
    const out: string[] = []
    let m: RegExpExecArray | null
    while ((m = re.exec(text)) !== null) out.push(m[1])
    return out
  }

  // ── Send a single message (also called by the queue drain) ─────────────
  const sendNow = useCallback(async (text: string, mentions: string[]) => {
    if (!activeChatId) return
    if (!apiKeys.gemini) {
      toast.error("Set your Gemini API key in Settings → Agents.")
      return
    }
    const userMsg: AgentMessage = {
      id: nanoid(), chatId: activeChatId,
      subChatId: activeSubChatId ?? undefined,
      role: "user", content: text, mentions: mentions.length ? mentions : undefined,
      createdAt: Date.now(),
    }
    await db.messages.add(userMsg)
    setMessages((prev) => [...prev, userMsg])

    // ─── Slash-command handlers ────────────────────────────────────────
    if (text.startsWith("/plan ")) {
      const goal = text.slice(6).trim()
      // produce a synthetic plan locally if no API; otherwise call /api/agents/plan
      try {
        const res = await fetch("/api/agents/plan", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ goal, apiKey: apiKeys.gemini, model: defaultModel }),
        })
        const data = await res.json()
        const steps: PlanStepView[] = Array.isArray(data?.plan) ? data.plan : [
          { title: "Implement goal", description: goal, doneCriteria: "Result delivered" },
        ]
        setPendingPlan({ goal, steps })
        const sys: AgentMessage = {
          id: nanoid(), chatId: activeChatId, subChatId: activeSubChatId ?? undefined,
          role: "system", content: `🧭 Draft plan ready (${steps.length} steps). Review below.`,
          plan: steps, createdAt: Date.now(),
        }
        await db.messages.add(sys)
        setMessages((prev) => [...prev, sys])
      } catch (e) {
        toast.error(`Plan failed: ${String(e)}`)
      }
      return
    }
    if (text.startsWith("/build ")) {
      setBuilding(true)
      const goal = text.slice(7)
      const placeholder: AgentMessage = {
        id: nanoid(), chatId: activeChatId, subChatId: activeSubChatId ?? undefined,
        role: "system", content: `🧭 Planning: ${goal}`, createdAt: Date.now(),
      }
      await db.messages.add(placeholder)
      setMessages((prev) => [...prev, placeholder])
      try { await orchestrator.run(activeChatId, goal) }
      catch (e) { toast.error(`Build failed: ${String(e)}`) }
      setBuilding(false)
      return
    }
    if (text === "/clear") {
      setMessages([])
      toast.success("Visible transcript cleared (history kept).")
      return
    }
    if (text.startsWith("/agent ")) {
      const id = text.slice(7).trim()
      const p = DEFAULT_PERSONAS.find((x) => x.id === id)
      if (p) {
        setPersona(p.id)
        await db.chats.update(activeChatId, { agentId: p.id, updatedAt: Date.now() })
        toast.success(`Persona switched → ${p.emoji} ${p.name}`)
      } else {
        toast.error(`Unknown persona: ${id}. Try ${DEFAULT_PERSONAS.map((p) => p.id).join(", ")}`)
      }
      return
    }
    if (text === "/design") { toggleDesignMode(); toast("Toggled design ↔ preview"); return }
    if (text === "/tokens") { window.dispatchEvent(new CustomEvent("astrolaunch:request-tokens")); toast("Token sync requested"); return }
    if (text === "/export") { window.dispatchEvent(new CustomEvent("astrolaunch:export-frame")); toast("Frame export requested"); return }
    if (text === "/rollback") { window.dispatchEvent(new CustomEvent("astrolaunch:rollback")); toast("Rollback requested"); return }
    if (text === "/queue") { setBottomTab("agent-log"); toast("Queue is shown above the input"); return }
    if (text.startsWith("/run ")) {
      const cmd = text.slice(5)
      window.dispatchEvent(new CustomEvent("astrolaunch:run-shell", { detail: cmd }))
      toast(`Sent to terminal: ${cmd}`)
      return
    }

    // ─── Streaming chat ───────────────────────────────────────────────
    setStreaming(true)
    const assistantId = nanoid()
    const assistantMsg: AgentMessage = {
      id: assistantId, chatId: activeChatId, subChatId: activeSubChatId ?? undefined,
      role: "assistant", content: "", createdAt: Date.now(), personaId: persona,
    }
    setMessages((prev) => [...prev, assistantMsg])
    abortStreamRef.current = new AbortController()
    try {
      const ctxMessages = messages.concat(userMsg).map((m) => ({
        role: m.role === "tool" ? "assistant" : m.role,
        content: m.content,
      }))
      // attach mentioned files as a system pre-message (read-only context)
      let mentionContext = ""
      if (mentions.length) {
        const files = await db.files.toArray()
        for (const path of mentions) {
          const f = files.find((x) => x.path === path || x.path === `/${path}`)
          if (f?.content) mentionContext += `\n\n--- ${path} ---\n${f.content.slice(0, 8_000)}`
        }
      }
      const sys = DEFAULT_PERSONAS.find((p) => p.id === persona)?.systemPrompt
      const finalSys = mentionContext ? `${sys ?? ""}\n\nReferenced files:${mentionContext}` : sys

      const res = await fetch("/api/agents/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: ctxMessages,
          apiKey: apiKeys.gemini, model: defaultModel,
          systemPrompt: finalSys,
        }),
        signal: abortStreamRef.current.signal,
      })
      if (!res.ok || !res.body) throw new Error(await res.text())
      const reader = res.body.getReader()
      const decoder = new TextDecoder()
      let buffer = ""
      let acc = ""
      let finalUsage: { input: number; output: number; model: string } | null = null
      const promptText = JSON.stringify(ctxMessages.map((m) => m.content))
      while (true) {
        const { value, done } = await reader.read()
        if (done) break
        buffer += decoder.decode(value, { stream: true })
        const frames = buffer.split("\n\n")
        buffer = frames.pop() ?? ""
        for (const frame of frames) {
          const m = /^data:\s*(.*)$/m.exec(frame)
          if (!m) continue
          try {
            const obj = JSON.parse(m[1])
            if (obj.delta) {
              acc += obj.delta
              setMessages((prev) => prev.map((mm) => mm.id === assistantId ? { ...mm, content: acc } : mm))
            } else if (obj.usage) finalUsage = obj.usage
            else if (obj.error) throw new Error(obj.error)
          } catch {}
        }
      }
      const usageObj = finalUsage
        ? { ...finalUsage, total: finalUsage.input + finalUsage.output, costUsd: estimateCost(finalUsage.model, finalUsage.input, finalUsage.output) }
        : approxUsage(defaultModel, promptText, acc)
      const finalMsg: AgentMessage = { ...assistantMsg, content: acc, usage: usageObj }
      await db.messages.add(finalMsg)
      setMessages((prev) => prev.map((mm) => mm.id === assistantId ? finalMsg : mm))
      setAccumulatedCost((c) => c + usageObj.costUsd)
      setAccumulatedTokens((t) => t + usageObj.total)
      const chat = await db.chats.get(activeChatId)
      if (chat) {
        await db.chats.update(activeChatId, {
          totalCostUsd: (chat.totalCostUsd ?? 0) + usageObj.costUsd,
          totalTokens: (chat.totalTokens ?? 0) + usageObj.total,
          updatedAt: Date.now(),
        })
      }
    } catch (e) {
      const msg = String(e)
      setMessages((prev) => prev.map((m) => m.id === assistantId ? { ...m, content: `⚠️ ${msg}` } : m))
    } finally {
      setStreaming(false)
      abortStreamRef.current = null
    }
  }, [activeChatId, activeSubChatId, apiKeys.gemini, defaultModel, messages, persona, setBottomTab, toggleDesignMode])

  // ── Top-level submit (queue if busy) ────────────────────────────────────
  const send = async () => {
    const text = input.trim()
    if (!text || !activeChatId) return
    setInput("")
    const mentions = parseMentions(text)
    if (streaming || building) {
      // queue
      const q: QueuedMessage = {
        id: nanoid(), chatId: activeChatId,
        subChatId: activeSubChatId ?? undefined,
        content: text,
        mentions,
        createdAt: Date.now(),
      }
      await db.queue.add(q)
      toast(`Queued (${text.length > 40 ? text.slice(0, 40) + "…" : text})`)
      return
    }
    await sendNow(text, mentions)
  }

  const onDrainQueue = useCallback(async (q: QueuedMessage) => {
    await sendNow(q.content, q.mentions ?? [])
  }, [sendNow])

  const renameChat = async (n: string) => {
    if (!activeChatId) return
    setChatName(n)
    await db.chats.update(activeChatId, { name: n, updatedAt: Date.now() })
  }

  const onPickSlash = (cmd: SlashCommand) => {
    const tpl = cmd.template ?? `${cmd.label} `
    setInput(tpl)
    setShowSlash(false)
    setTimeout(() => inputRef.current?.focus(), 0)
  }

  const onPickMention = (path: string) => {
    const lastSpace = input.lastIndexOf(" ")
    const head = lastSpace >= 0 ? input.slice(0, lastSpace + 1) : ""
    setInput(`${head}@${path} `)
    setShowMention(false)
    setTimeout(() => inputRef.current?.focus(), 0)
  }

  const approvePlan = async (steps: PlanStepView[]) => {
    if (!pendingPlan || !activeChatId) return
    setPendingPlan(null)
    setBuilding(true)
    const sys: AgentMessage = {
      id: nanoid(), chatId: activeChatId, subChatId: activeSubChatId ?? undefined,
      role: "system", content: `▶ Executing approved plan (${steps.length} steps).`,
      createdAt: Date.now(),
    }
    await db.messages.add(sys)
    setMessages((prev) => [...prev, sys])
    try { await orchestrator.run(activeChatId, pendingPlan.goal) }
    catch (e) { toast.error(`Run failed: ${String(e)}`) }
    setBuilding(false)
  }

  const onFork = async (m: AgentMessage) => {
    const newId = await forkChatAtMessage(m)
    if (newId) {
      setActiveChatId(newId)
      toast.success("Forked into a new chat")
    }
  }

  const onRollback = async (m: AgentMessage) => {
    if (!activeChatId) return
    if (!confirm("Rollback removes all messages after this one — continue?")) return
    const all = await db.messages.where("chatId").equals(activeChatId).sortBy("createdAt")
    const idx = all.findIndex((x) => x.id === m.id)
    if (idx < 0) return
    const toDelete = all.slice(idx + 1)
    for (const x of toDelete) await db.messages.delete(x.id)
    const after = all.slice(0, idx + 1)
    setMessages(activeSubChatId
      ? after.filter((x) => x.subChatId === activeSubChatId)
      : after.filter((x) => !x.subChatId))
    toast.success(`Rolled back ${toDelete.length} message(s)`)
  }

  // Header + cost bar visibility helpers
  const overCap = costCapUsd > 0 && accumulatedCost >= costCapUsd
  const nearCap = costCapUsd > 0 && accumulatedCost >= costCapUsd * 0.8

  // pending plan from latest system message that has a plan field
  const lastPlanMsg = useMemo(
    () => [...messages].reverse().find((m) => m.role === "system" && Array.isArray(m.plan) && m.plan.length > 0),
    [messages]
  )

  if (!showRightChat) return null

  if (agentChatMinimized) {
    return (
      <motion.button
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        onClick={() => setAgentChatMinimized(false)}
        style={{ left: agentChatPosition.x, top: agentChatPosition.y }}
        className="fixed z-40 rounded-full bg-gradient-to-br from-al-chat/95 to-al-panel/90 border border-al-accent/30 shadow-2xl shadow-al-accent/15 backdrop-blur px-3 py-2 flex items-center gap-2 text-xs hover:scale-105 transition-transform"
      >
        <AppIcon name="agent" width={14} className="text-al-accent" />
        Agent {(building || streaming) && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />}
        <Badge variant="outline" className="text-[9px] py-0 px-1">${accumulatedCost.toFixed(3)}</Badge>
      </motion.button>
    )
  }

  return (
    <motion.div
      ref={containerRef}
      drag
      dragControls={dragControls}
      dragListener={false}
      dragMomentum={false}
      initial={{ x: agentChatPosition.x, y: agentChatPosition.y, opacity: 0, scale: 0.96 }}
      animate={{ x: agentChatPosition.x, y: agentChatPosition.y, opacity: 1, scale: 1 }}
      onDragEnd={(_, info) => setAgentChatPosition({ x: info.point.x - 200, y: info.point.y - 16 })}
      className="fixed z-40 rounded-2xl border border-border/80 shadow-2xl shadow-black/40 bg-al-chat/85 backdrop-blur-xl flex flex-col overflow-hidden ring-1 ring-white/5"
      style={{ width: agentChatSize.w, height: agentChatSize.h }}
    >
      {/* Drag handle / header */}
      <div
        onPointerDown={(e) => dragControls.start(e)}
        className="h-9 flex items-center gap-2 px-3 bg-gradient-to-r from-al-panel via-al-panel/80 to-al-panel border-b border-border cursor-move select-none"
      >
        <div className="w-5 h-5 rounded-md bg-gradient-to-br from-violet-500 via-fuchsia-500 to-cyan-400 grid place-items-center text-[10px] text-white shadow shadow-violet-500/30">⌁</div>
        <input
          value={chatName}
          onChange={(e) => renameChat(e.target.value)}
          className="bg-transparent border-0 outline-none text-xs font-medium w-32"
        />
        <div className="ml-1 flex bg-background/40 rounded-md p-0.5 text-[10px] border border-border/40">
          {(["chat", "tasks", "stats"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={cn(
                "px-2 py-0.5 rounded transition",
                tab === t ? "bg-al-accent/30 text-foreground" : "text-muted-foreground hover:text-foreground"
              )}
            >
              {t === "chat" ? "Chat" : t === "tasks" ? `Tasks (${tasks.filter((x) => !x.is_done).length}/${tasks.length})` : "Stats"}
            </button>
          ))}
        </div>
        <div className="ml-auto flex items-center gap-1">
          <Select value={persona} onValueChange={setPersona}>
            <SelectTrigger className="h-6 text-[10px] w-[110px] border-border/60"><SelectValue /></SelectTrigger>
            <SelectContent>
              {DEFAULT_PERSONAS.map((p) => (
                <SelectItem key={p.id} value={p.id}>{p.emoji} {p.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={defaultModel} onValueChange={(v) => set("defaultModel", v as "gemini-2.5-pro" | "gemini-2.5-flash")}>
            <SelectTrigger className="h-6 text-[10px] w-[120px] border-border/60"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="gemini-2.5-pro">Gemini 2.5 Pro</SelectItem>
              <SelectItem value="gemini-2.5-flash">Gemini 2.5 Flash</SelectItem>
            </SelectContent>
          </Select>
          <Button size="icon-sm" variant="ghost" onClick={() => setAgentChatMinimized(true)} title="Minimize">
            <AppIcon name="close" width={12} />
          </Button>
        </div>
      </div>

      {/* Sub-chat tab strip */}
      {tab === "chat" && <SubChatTabs />}

      {/* Cost / status bar */}
      <div className={cn(
        "px-3 py-1 flex items-center gap-3 text-[10px] border-b border-border/60",
        overCap ? "bg-red-500/10 text-red-300" : nearCap ? "bg-amber-500/10 text-amber-300" : "bg-background/30 text-muted-foreground",
        (streaming || building) && "al-agent-running"
      )}>
        <span className="font-medium">${accumulatedCost.toFixed(4)}</span>
        {costCapUsd > 0 && <span>· cap ${costCapUsd.toFixed(2)}</span>}
        <span>· {accumulatedTokens.toLocaleString()} tokens</span>
        <span className="opacity-50">· {priceFor(defaultModel).provider}</span>
        {(streaming || building) && (
          <Button size="sm" variant="ghost" className="h-5 ml-auto text-[10px]" onClick={abortAll}>
            <AppIcon name="stop" width={10} /> Abort
          </Button>
        )}
      </div>

      {/* Body */}
      <AnimatePresence mode="wait">
        {tab === "chat" ? (
          <motion.div key="chat" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex-1 flex flex-col min-h-0">
            <div ref={messagesRef} className="flex-1 overflow-auto px-3 py-3 space-y-3 text-sm">
              {messages.length === 0 && (
                <div className="text-xs text-muted-foreground space-y-2 p-3 bg-background/30 rounded-md border border-border">
                  <div className="font-medium text-foreground flex items-center gap-1.5">
                    <AppIcon name="spark" width={12} className="text-al-accent" /> Welcome to the Agent.
                  </div>
                  <ul className="space-y-1 list-disc list-inside marker:text-al-accent">
                    <li>Plain message → streaming chat with Gemini.</li>
                    <li><code className="bg-background px-1 rounded">/plan &lt;goal&gt;</code> → architect drafts; you approve.</li>
                    <li><code className="bg-background px-1 rounded">/build &lt;goal&gt;</code> → full architect → builder → reviewer loop.</li>
                    <li><code className="bg-background px-1 rounded">@file/path</code> → attach files as context.</li>
                    <li>Hover any message → copy / fork / rollback.</li>
                  </ul>
                </div>
              )}
              {messages.map((m, idx) => (
                <div key={m.id}>
                  <MessageView
                    message={m}
                    streaming={streaming && idx === messages.length - 1 && m.role === "assistant"}
                    showDiffs={showToolDiffs}
                    onFork={onFork}
                    onRollback={onRollback}
                  />
                  {/* Render plan card under the system message that carries it */}
                  {m.role === "system" && Array.isArray(m.plan) && m.plan.length > 0 && lastPlanMsg?.id === m.id && pendingPlan && (
                    <div className="mt-2 ml-2">
                      <PlanCard
                        plan={m.plan}
                        onApprove={(s) => approvePlan(s)}
                        onDiscard={() => { setPendingPlan(null); toast("Plan discarded") }}
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Queue display */}
            <MessageQueue busy={streaming || building} onDrain={onDrainQueue} />

            <div className="border-t border-border p-2 space-y-2 relative bg-al-panel/50">
              {/* slash + mentions */}
              {showSlash && (
                <SlashCommandPalette query={slashQuery} onPick={onPickSlash} onClose={() => setShowSlash(false)} />
              )}
              {showMention && (
                <FileMentionPicker query={mentionQuery} onPick={onPickMention} onClose={() => setShowMention(false)} />
              )}
              <Textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey && !showSlash && !showMention) {
                    e.preventDefault(); send()
                  }
                }}
                placeholder="Ask anything · / for commands · @ for files"
                className="text-xs resize-none focus-visible:ring-al-accent/40"
                rows={2}
              />
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-muted-foreground">
                  ⏎ send · ⇧⏎ newline · / commands · @ files
                </span>
                <Button size="sm" onClick={send} disabled={!input.trim()}
                  className={cn(
                    "shadow shadow-al-accent/10",
                    (streaming || building) && "bg-amber-500 hover:bg-amber-500/90"
                  )}>
                  {(streaming || building) ? "Queue" : "Send"} <AppIcon name="play" width={10} />
                </Button>
              </div>
            </div>
          </motion.div>
        ) : tab === "tasks" ? (
          <motion.div key="tasks" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex-1 overflow-auto p-3 space-y-2 text-xs">
            {tasks.length === 0 && <div className="text-muted-foreground">No tasks yet. Use <code>/build &lt;goal&gt;</code> to spawn.</div>}
            {tasks.map((t) => (
              <div key={t.id} className={cn(
                "rounded-md border border-border p-2 space-y-1 transition",
                t.is_done && "border-emerald-600/40 bg-emerald-500/5",
                t.status === "failed" && "border-red-600/40 bg-red-500/5",
                t.status === "in_progress" && "border-al-accent/40 bg-al-accent/5"
              )}>
                <div className="flex items-center gap-2">
                  <span>{t.is_done ? "✓" : t.status === "failed" ? "✗" : t.status === "in_progress" ? "▶" : "○"}</span>
                  <span className="font-medium flex-1 truncate">{t.title}</span>
                  <span className="text-[10px] text-muted-foreground">{t.iterations}/{t.maxIterations}</span>
                  {!!t.retries && <Badge variant="outline" className="text-[9px] py-0 px-1">⟲{t.retries}</Badge>}
                </div>
                <div className="text-[11px] text-muted-foreground">{t.description}</div>
                <div className="text-[10px] text-muted-foreground italic">done if: {t.doneCriteria}</div>
                {t.evidence && <div className="text-[10px] text-emerald-400">✓ {t.evidence}</div>}
                {t.toolHistory && t.toolHistory.length > 0 && (
                  <div className="flex flex-wrap gap-1 pt-1">
                    {t.toolHistory.slice(-6).map((h, i) => (
                      <span key={i} className={cn(
                        "text-[9px] px-1 rounded",
                        h.ok ? "bg-emerald-500/20 text-emerald-300" : "bg-red-500/20 text-red-300"
                      )}>{h.name}</span>
                    ))}
                  </div>
                )}
              </div>
            ))}
            <div className="pt-2 border-t border-border">
              <div className="text-[10px] uppercase text-muted-foreground mb-1">Orchestrator log</div>
              <div className="font-mono text-[10px] text-muted-foreground space-y-0.5 max-h-32 overflow-auto">
                {logs.slice(-30).map((l, i) => <div key={i} className="truncate">{l}</div>)}
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div key="stats" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex-1 overflow-auto p-3 space-y-3 text-xs">
            <StatGrid messages={messages} tasks={tasks} cost={accumulatedCost} tokens={accumulatedTokens} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Resize handle */}
      <div
        onPointerDown={(e) => {
          e.preventDefault()
          const startW = agentChatSize.w, startH = agentChatSize.h, sx = e.clientX, sy = e.clientY
          const move = (ev: PointerEvent) => setAgentChatSize({
            w: Math.max(380, startW + (ev.clientX - sx)),
            h: Math.max(380, startH + (ev.clientY - sy)),
          })
          const up = () => { window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up) }
          window.addEventListener("pointermove", move); window.addEventListener("pointerup", up)
        }}
        className="absolute bottom-0 right-0 w-3 h-3 cursor-nwse-resize opacity-50 hover:opacity-100"
        style={{ background: "linear-gradient(135deg, transparent 50%, hsl(var(--al-accent)) 50%)" }}
      />
    </motion.div>
  )
}

function StatGrid({ messages, tasks, cost, tokens }: { messages: AgentMessage[]; tasks: AgentTask[]; cost: number; tokens: number }) {
  const toolCalls = messages.filter((m) => m.role === "tool").length
  const toolErrors = messages.filter((m) => m.role === "tool" && m.toolCalls?.[0]?.status === "error").length
  const completed = tasks.filter((t) => t.is_done).length
  const failed = tasks.filter((t) => t.status === "failed").length
  return (
    <div className="grid grid-cols-2 gap-2">
      <Stat label="Cost" value={`$${cost.toFixed(4)}`} />
      <Stat label="Tokens" value={tokens.toLocaleString()} />
      <Stat label="Tasks done" value={`${completed}/${tasks.length}`} accent="text-emerald-400" />
      <Stat label="Tasks failed" value={String(failed)} accent={failed > 0 ? "text-red-400" : ""} />
      <Stat label="Tool calls" value={String(toolCalls)} />
      <Stat label="Tool errors" value={String(toolErrors)} accent={toolErrors > 0 ? "text-amber-400" : ""} />
      <Stat label="Messages" value={String(messages.length)} />
      <Stat label="Avg per task" value={tasks.length ? `${(tokens / tasks.length).toFixed(0)} tok` : "—"} />
    </div>
  )
}
function Stat({ label, value, accent }: { label: string; value: string; accent?: string }) {
  return (
    <div className="rounded-md border border-border p-2 bg-background/40">
      <div className="text-[10px] uppercase text-muted-foreground">{label}</div>
      <div className={cn("text-sm font-semibold", accent)}>{value}</div>
    </div>
  )
}

// SLASH_COMMANDS reference kept for tree-shaking awareness
void SLASH_COMMANDS
