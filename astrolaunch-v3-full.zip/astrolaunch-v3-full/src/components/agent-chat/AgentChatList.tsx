"use client"
/**
 * Connected agent chat sidebar — left-rail "Agents" tab.
 *
 *   - Persona quick-spawn grid with brand colors
 *   - Search box + tab filter (active / archived / forks)
 *   - Visual cost / token chip per chat
 *   - Hover actions: open, archive, duplicate, delete
 *   - Drag-to-reorder is intentionally omitted — order is by updatedAt.
 */
import { useEffect, useState, useMemo } from "react"
import { db } from "@/lib/storage/db"
import { useWorkspace } from "@/store/workspace"
import type { AgentChat } from "@/types"
import { Button } from "@/components/ui/button"
import { AppIcon } from "@/lib/iconify"
import { Input } from "@/components/ui/input"
import { nanoid } from "nanoid"
import { cn } from "@/lib/utils"
import { DEFAULT_PERSONAS } from "@/lib/agents/personas"
import { motion, AnimatePresence } from "framer-motion"
import { Badge } from "@/components/ui/badge"

type Filter = "active" | "archived" | "forks"

export function AgentChatList() {
  const { activeChatId, setActiveChatId, setShowRightChat, setAgentChatMinimized } = useWorkspace()
  const [chats, setChats] = useState<AgentChat[]>([])
  const [query, setQuery] = useState("")
  const [filter, setFilter] = useState<Filter>("active")

  const refresh = async () => {
    if (!db) return
    setChats(await db.chats.orderBy("updatedAt").reverse().toArray())
  }
  useEffect(() => {
    refresh()
    const t = setInterval(refresh, 2000)
    return () => clearInterval(t)
  }, [])

  const create = async (agentId: string) => {
    const id = nanoid()
    const persona = DEFAULT_PERSONAS.find((p) => p.id === agentId)
    await db.chats.add({
      id, name: `${persona?.name ?? "Agent"} Chat`,
      agentId, createdAt: Date.now(), updatedAt: Date.now(),
      color: persona?.color,
    })
    setActiveChatId(id); setShowRightChat(true); setAgentChatMinimized(false); refresh()
  }

  const archive = async (id: string, archived: 0 | 1) => {
    await db.chats.update(id, { archived, updatedAt: Date.now() })
    if (archived === 1 && activeChatId === id) setActiveChatId(null)
    refresh()
  }

  const remove = async (id: string) => {
    if (!confirm("Permanently delete this chat (messages + tasks)?")) return
    const msgs = await db.messages.where("chatId").equals(id).primaryKeys()
    const tasks = await db.tasks.where("chatId").equals(id).primaryKeys()
    const subs = await db.subChats.where("chatId").equals(id).primaryKeys()
    await db.messages.bulkDelete(msgs)
    await db.tasks.bulkDelete(tasks)
    await db.subChats.bulkDelete(subs)
    await db.chats.delete(id)
    if (activeChatId === id) setActiveChatId(null)
    refresh()
  }

  const duplicate = async (id: string) => {
    const src = await db.chats.get(id)
    if (!src) return
    const newId = nanoid()
    await db.chats.add({ ...src, id: newId, name: `${src.name} (copy)`, createdAt: Date.now(), updatedAt: Date.now(), archived: 0 })
    refresh()
  }

  const visible = useMemo(() => {
    let pool = chats
    if (filter === "active") pool = pool.filter((c) => c.archived !== 1)
    if (filter === "archived") pool = pool.filter((c) => c.archived === 1)
    if (filter === "forks") pool = pool.filter((c) => !!c.parentChatId)
    if (query) {
      const q = query.toLowerCase()
      pool = pool.filter((c) => c.name.toLowerCase().includes(q) || c.agentId.includes(q))
    }
    return pool
  }, [chats, filter, query])

  return (
    <div className="h-full flex flex-col text-xs">
      {/* Persona spawn grid */}
      <div className="p-2 border-b border-border space-y-1.5">
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground flex items-center gap-1">
          <AppIcon name="spark" width={10} className="text-al-accent" />
          Spawn agent
        </div>
        <div className="grid grid-cols-2 gap-1">
          {DEFAULT_PERSONAS.map((p) => (
            <button
              key={p.id}
              onClick={() => create(p.id)}
              className="group flex items-center gap-1.5 px-2 py-1.5 rounded-md border border-border bg-background/30 hover:bg-accent/40 transition text-left relative overflow-hidden"
              style={{ borderLeftColor: p.color, borderLeftWidth: 2 }}
            >
              <span className="text-base">{p.emoji}</span>
              <div className="overflow-hidden">
                <div className="font-medium truncate">{p.name}</div>
                <div className="text-[10px] text-muted-foreground truncate">{p.description}</div>
              </div>
              <span
                className="absolute inset-0 opacity-0 group-hover:opacity-10 transition pointer-events-none"
                style={{ background: `radial-gradient(circle at top left, ${p.color}, transparent 60%)` }}
              />
            </button>
          ))}
        </div>
      </div>

      {/* Filter row */}
      <div className="p-2 space-y-2 border-b border-border">
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search chats…"
          className="h-7 text-[11px]"
        />
        <div className="flex gap-1 text-[10px]">
          {(["active", "archived", "forks"] as Filter[]).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "px-2 py-0.5 rounded transition",
                filter === f ? "bg-al-accent/25 text-foreground" : "text-muted-foreground hover:bg-accent/40"
              )}
            >
              {f}
            </button>
          ))}
          <span className="ml-auto text-muted-foreground">{visible.length}</span>
        </div>
      </div>

      {/* List */}
      <div className="flex-1 overflow-auto">
        <AnimatePresence>
          {visible.map((c) => {
            const persona = DEFAULT_PERSONAS.find((p) => p.id === c.agentId)
            const cost = c.totalCostUsd ?? 0
            return (
              <motion.div
                key={c.id}
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, height: 0 }}
                whileHover={{ x: 2 }}
                onClick={() => { setActiveChatId(c.id); setShowRightChat(true); setAgentChatMinimized(false) }}
                className={cn(
                  "group flex items-center gap-2 px-3 py-2 cursor-pointer hover:bg-accent/30 border-l-2 border-transparent",
                  activeChatId === c.id && "bg-al-accent/15 text-foreground border-l-al-accent"
                )}
                style={activeChatId === c.id ? undefined : { borderLeftColor: c.color ? `${c.color}55` : undefined }}
              >
                <span>{persona?.emoji ?? "🤖"}</span>
                <div className="truncate flex-1 min-w-0">
                  <div className="truncate flex items-center gap-1">
                    {c.parentChatId && <span className="opacity-60 text-[9px]">↗</span>}
                    {c.name}
                  </div>
                  {cost > 0 && (
                    <div className="text-[9px] text-muted-foreground">
                      ${cost.toFixed(4)} · {(c.totalTokens ?? 0).toLocaleString()} tok
                    </div>
                  )}
                </div>
                {cost > 0.5 && <Badge variant="warning" className="text-[9px] py-0 px-1">$</Badge>}
                <div className="opacity-0 group-hover:opacity-100 flex items-center gap-0.5">
                  <button
                    onClick={(e) => { e.stopPropagation(); duplicate(c.id) }}
                    className="hover:text-foreground p-1" title="Duplicate"
                  >
                    <AppIcon name="copy" width={10} />
                  </button>
                  {c.archived === 1 ? (
                    <button onClick={(e) => { e.stopPropagation(); archive(c.id, 0) }} className="hover:text-foreground p-1" title="Restore">
                      <AppIcon name="upload" width={10} />
                    </button>
                  ) : (
                    <button onClick={(e) => { e.stopPropagation(); archive(c.id, 1) }} className="hover:text-foreground p-1" title="Archive">
                      <AppIcon name="download" width={10} />
                    </button>
                  )}
                  <button onClick={(e) => { e.stopPropagation(); remove(c.id) }} className="hover:text-destructive p-1" title="Delete">
                    <AppIcon name="trash" width={10} />
                  </button>
                </div>
              </motion.div>
            )
          })}
        </AnimatePresence>
        {visible.length === 0 && (
          <div className="p-3 text-muted-foreground">
            {filter === "active" ? "No chats yet. Spawn an agent above." :
             filter === "archived" ? "No archived chats." : "No forks yet."}
          </div>
        )}
      </div>

      <div className="border-t border-border p-2">
        <Button size="sm" variant="outline" className="w-full text-xs" onClick={() => { setShowRightChat(true); setAgentChatMinimized(false) }}>
          <AppIcon name="chat" width={12} /> Open floating chat
        </Button>
      </div>
    </div>
  )
}
