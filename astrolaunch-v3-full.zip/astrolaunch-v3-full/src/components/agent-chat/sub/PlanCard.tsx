"use client"
/**
 * Plan mode card — renders a structured plan with approve / edit / discard.
 *
 * Used when a user invokes `/plan <goal>` or when the architect emits a plan
 * pre-execution. The chat parks the plan as a system message; the card lets
 * the user tweak step ordering, edit doneCriteria, and approve before the
 * orchestrator executes.
 */
import { useState } from "react"
import type { PlanStepView } from "@/types"
import { Button } from "@/components/ui/button"
import { AppIcon } from "@/lib/iconify"
import { Textarea } from "@/components/ui/textarea"
import { motion, Reorder } from "framer-motion"
import { cn } from "@/lib/utils"

interface Props {
  plan: PlanStepView[]
  onApprove: (plan: PlanStepView[]) => void
  onDiscard: () => void
}

export function PlanCard({ plan, onApprove, onDiscard }: Props) {
  const [steps, setSteps] = useState<PlanStepView[]>(plan)
  const [editing, setEditing] = useState<number | null>(null)

  const update = (i: number, patch: Partial<PlanStepView>) =>
    setSteps((prev) => prev.map((s, idx) => idx === i ? { ...s, ...patch } : s))

  const remove = (i: number) =>
    setSteps((prev) => prev.filter((_, idx) => idx !== i))

  const add = () =>
    setSteps((prev) => [...prev, { title: "New step", description: "", doneCriteria: "Verifiable outcome" }])

  return (
    <motion.div
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-lg border border-al-accent/30 bg-gradient-to-b from-al-accent/8 to-transparent p-2.5 space-y-2 text-xs shadow-lg shadow-al-accent/5"
    >
      <div className="flex items-center gap-2">
        <AppIcon name="spark" width={13} className="text-al-accent" />
        <span className="font-semibold tracking-tight">Plan ({steps.length} steps)</span>
        <span className="text-[10px] text-muted-foreground ml-auto">drag to reorder · double-click to edit</span>
      </div>

      <Reorder.Group axis="y" values={steps} onReorder={setSteps} className="space-y-1.5">
        {steps.map((s, i) => (
          <Reorder.Item
            key={s.title + i}
            value={s}
            className={cn(
              "rounded-md border border-border bg-background/40 p-2 cursor-grab active:cursor-grabbing",
              s.approved && "border-emerald-500/40 bg-emerald-500/5"
            )}
          >
            <div className="flex items-start gap-2">
              <span className="w-5 h-5 rounded bg-al-accent/20 text-al-accent grid place-items-center text-[10px] font-mono shrink-0 mt-0.5">
                {i + 1}
              </span>
              <div className="flex-1 min-w-0" onDoubleClick={() => setEditing(editing === i ? null : i)}>
                <div className="font-medium truncate">{s.title}</div>
                <div className="text-muted-foreground text-[11px] truncate">{s.description}</div>
                <div className="text-emerald-400/80 text-[10px] mt-0.5 italic truncate">done if: {s.doneCriteria}</div>
              </div>
              <button
                onClick={() => remove(i)}
                className="opacity-50 hover:opacity-100 hover:text-destructive"
                title="Remove step"
              >
                <AppIcon name="close" width={10} />
              </button>
            </div>
            {editing === i && (
              <div className="mt-2 space-y-1">
                <input
                  className="w-full bg-background/70 border border-border rounded px-1.5 py-0.5 text-[11px] outline-none focus:border-al-accent/60"
                  value={s.title}
                  onChange={(e) => update(i, { title: e.target.value })}
                  placeholder="Title"
                />
                <Textarea
                  rows={2}
                  className="text-[11px]"
                  value={s.description}
                  onChange={(e) => update(i, { description: e.target.value })}
                  placeholder="Description"
                />
                <input
                  className="w-full bg-background/70 border border-border rounded px-1.5 py-0.5 text-[11px] outline-none focus:border-emerald-500/60"
                  value={s.doneCriteria}
                  onChange={(e) => update(i, { doneCriteria: e.target.value })}
                  placeholder="Done criteria"
                />
              </div>
            )}
          </Reorder.Item>
        ))}
      </Reorder.Group>

      <div className="flex items-center gap-1.5 pt-1">
        <Button size="sm" variant="ghost" className="h-6 text-[10px]" onClick={add}>
          <AppIcon name="plus" width={10} /> Step
        </Button>
        <div className="ml-auto flex gap-1.5">
          <Button size="sm" variant="ghost" className="h-6 text-[10px]" onClick={onDiscard}>
            Discard
          </Button>
          <Button size="sm" className="h-6 text-[10px]" onClick={() => onApprove(steps)}>
            <AppIcon name="play" width={10} /> Approve & Run
          </Button>
        </div>
      </div>
    </motion.div>
  )
}
