"use client"
/**
 * Slash command palette inside the chat input.
 *
 * Matches 1code's command set (/plan, /agent, /clear, /fork, /queue, /run,
 * /design, /tokens, /export). Activates when the input starts with "/".
 */
import { useEffect, useState, useMemo } from "react"
import { AppIcon } from "@/lib/iconify"
import { cn } from "@/lib/utils"
import { motion, AnimatePresence } from "framer-motion"

export interface SlashCommand {
  id: string
  label: string
  hint: string
  icon: string
  /** Optional template inserted on activation. */
  template?: string
}

export const SLASH_COMMANDS: SlashCommand[] = [
  { id: "plan",    label: "/plan",    hint: "Build a structured plan with clarifying questions", icon: "spark" },
  { id: "build",   label: "/build",   hint: "Run the full architect → builder → reviewer loop",   icon: "bolt" },
  { id: "agent",   label: "/agent",   hint: "Switch persona (architect, builder, designer…)",     icon: "agent" },
  { id: "fork",    label: "/fork",    hint: "Fork this conversation into a new chat",             icon: "diff" },
  { id: "clear",   label: "/clear",   hint: "Clear visible transcript (history kept)",            icon: "trash" },
  { id: "queue",   label: "/queue",   hint: "Show current message queue",                          icon: "more" },
  { id: "run",     label: "/run",     hint: "Run shell command in the integrated terminal",        icon: "terminal", template: "/run " },
  { id: "design",  label: "/design",  hint: "Toggle design ↔ preview surface",                     icon: "canvas" },
  { id: "tokens",  label: "/tokens",  hint: "Sync Penpot tokens → CSS variables",                  icon: "download" },
  { id: "export",  label: "/export",  hint: "Export current frame to SVG and attach",              icon: "upload" },
  { id: "rollback",label: "/rollback",hint: "Revert latest agent edits",                          icon: "refresh" },
]

interface Props {
  query: string
  onPick: (cmd: SlashCommand) => void
  onClose: () => void
}

export function SlashCommandPalette({ query, onPick, onClose }: Props) {
  const [hover, setHover] = useState(0)

  const filtered = useMemo(() => {
    const q = query.replace(/^\//, "").toLowerCase()
    if (!q) return SLASH_COMMANDS
    return SLASH_COMMANDS.filter((c) => c.id.includes(q) || c.label.includes(q))
  }, [query])

  useEffect(() => { setHover(0) }, [query])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowDown") { e.preventDefault(); setHover((h) => Math.min(h + 1, filtered.length - 1)) }
      else if (e.key === "ArrowUp") { e.preventDefault(); setHover((h) => Math.max(h - 1, 0)) }
      else if (e.key === "Enter" && filtered[hover]) { e.preventDefault(); onPick(filtered[hover]) }
      else if (e.key === "Escape") onClose()
    }
    window.addEventListener("keydown", onKey, true)
    return () => window.removeEventListener("keydown", onKey, true)
  }, [hover, filtered, onPick, onClose])

  if (filtered.length === 0) return null
  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 4 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 4 }}
        className="absolute bottom-full mb-1 left-2 right-2 z-30 rounded-md border border-border bg-al-panel/95 backdrop-blur-md shadow-2xl overflow-hidden"
      >
        <div className="px-2 py-1 text-[10px] uppercase tracking-wider text-muted-foreground flex items-center gap-1">
          <AppIcon name="spark" width={10} className="text-al-accent" />
          Slash commands
        </div>
        {filtered.map((c, i) => (
          <button
            key={c.id}
            onMouseEnter={() => setHover(i)}
            onClick={() => onPick(c)}
            className={cn(
              "w-full flex items-center gap-2 px-2 py-1 text-[11px] text-left",
              hover === i ? "bg-al-accent/20 text-foreground" : "text-muted-foreground hover:bg-accent/30"
            )}
          >
            <AppIcon name={c.icon} width={12} className={hover === i ? "text-al-accent" : ""} />
            <code className="font-mono w-20">{c.label}</code>
            <span className="truncate opacity-80">{c.hint}</span>
          </button>
        ))}
      </motion.div>
    </AnimatePresence>
  )
}
