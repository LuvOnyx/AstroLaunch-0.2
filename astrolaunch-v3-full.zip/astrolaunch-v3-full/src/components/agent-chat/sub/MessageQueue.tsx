"use client"
/**
 * MessageQueue — 1code-style queued prompts.
 *
 * The user can keep typing while an agent is busy; each new submission while
 * `streaming || building` is true gets parked here. When the agent goes idle
 * the floating chat drains the queue in order.
 */
import { useEffect, useState, useCallback } from "react"
import { db } from "@/lib/storage/db"
import { useWorkspace } from "@/store/workspace"
import { AppIcon } from "@/lib/iconify"
import { motion, AnimatePresence } from "framer-motion"
import type { QueuedMessage } from "@/types"

interface Props {
  busy: boolean
  onDrain: (q: QueuedMessage) => Promise<void>
}

export function MessageQueue({ busy, onDrain }: Props) {
  const { activeChatId, activeSubChatId } = useWorkspace()
  const [items, setItems] = useState<QueuedMessage[]>([])

  const refresh = useCallback(async () => {
    if (!db || !activeChatId) { setItems([]); return }
    let q = db.queue.where("chatId").equals(activeChatId)
    const all = await q.toArray()
    const filtered = all.filter((x) =>
      activeSubChatId ? x.subChatId === activeSubChatId : !x.subChatId
    )
    filtered.sort((a, b) => a.createdAt - b.createdAt)
    setItems(filtered)
  }, [activeChatId, activeSubChatId])

  useEffect(() => {
    refresh()
    const t = setInterval(refresh, 800)
    return () => clearInterval(t)
  }, [refresh])

  // Drain when idle
  useEffect(() => {
    if (busy || items.length === 0) return
    const next = items[0]
    if (next.sendingAt) return
    let cancelled = false
    ;(async () => {
      await db.queue.update(next.id, { sendingAt: Date.now() })
      try {
        await onDrain(next)
      } finally {
        if (!cancelled) {
          await db.queue.delete(next.id)
          refresh()
        }
      }
    })()
    return () => { cancelled = true }
  }, [busy, items, onDrain, refresh])

  const remove = async (id: string) => {
    await db.queue.delete(id)
    refresh()
  }

  if (items.length === 0) return null

  return (
    <div className="px-2 pb-1 space-y-1">
      <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
        <AppIcon name="bolt" width={10} className="text-amber-400" />
        <span>Queue ({items.length})</span>
        <span className="opacity-60">— drains automatically</span>
      </div>
      <AnimatePresence>
        {items.map((q) => (
          <motion.div
            key={q.id}
            initial={{ opacity: 0, x: -6, height: 0 }}
            animate={{ opacity: 1, x: 0, height: "auto" }}
            exit={{ opacity: 0, x: -6, height: 0 }}
            className="group flex items-start gap-2 p-1.5 rounded border border-amber-400/20 bg-amber-400/5 text-[11px]"
          >
            <span className={`mt-0.5 w-1.5 h-1.5 rounded-full ${q.sendingAt ? "bg-emerald-400 animate-pulse" : "bg-amber-400"}`} />
            <span className="flex-1 truncate">{q.content}</span>
            <button
              onClick={() => remove(q.id)}
              className="opacity-0 group-hover:opacity-100 hover:text-destructive"
              title="Cancel queued"
            >
              <AppIcon name="close" width={10} />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  )
}
