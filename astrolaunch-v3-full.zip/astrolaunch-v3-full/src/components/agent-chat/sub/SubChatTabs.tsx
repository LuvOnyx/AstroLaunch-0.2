"use client"
/**
 * Sub-chat tab strip — sits inside the floating agent chat header.
 *
 * Mirrors the 1code "tabs / sub-chats" model: each sub-chat is a focused
 * thread with its own message history. Tabs can be created, renamed, pinned
 * and dragged to reorder. Pinned tabs always sort to the front.
 */
import { useEffect, useState, useCallback, useRef } from "react"
import { db } from "@/lib/storage/db"
import { useWorkspace } from "@/store/workspace"
import { AppIcon } from "@/lib/iconify"
import { cn } from "@/lib/utils"
import { nanoid } from "nanoid"
import type { SubChat } from "@/types"
import { motion, AnimatePresence } from "framer-motion"

export function SubChatTabs() {
  const { activeChatId, activeSubChatId, setActiveSubChatId } = useWorkspace()
  const [subs, setSubs] = useState<SubChat[]>([])
  const [editing, setEditing] = useState<string | null>(null)
  const dragId = useRef<string | null>(null)

  const refresh = useCallback(async () => {
    if (!db || !activeChatId) { setSubs([]); return }
    const all = await db.subChats.where("chatId").equals(activeChatId).toArray()
    all.sort((a, b) => {
      const pa = a.pinned ? 1 : 0, pb = b.pinned ? 1 : 0
      if (pa !== pb) return pb - pa
      return (a.order ?? 0) - (b.order ?? 0)
    })
    setSubs(all)
  }, [activeChatId])

  useEffect(() => { refresh() }, [refresh, activeChatId])

  const create = useCallback(async () => {
    if (!activeChatId) return
    const id = nanoid()
    const sub: SubChat = {
      id, chatId: activeChatId, title: `Tab ${subs.length + 1}`,
      createdAt: Date.now(), updatedAt: Date.now(),
      order: subs.length,
    }
    await db.subChats.add(sub)
    setActiveSubChatId(id)
    refresh()
  }, [activeChatId, subs.length, refresh, setActiveSubChatId])

  const remove = async (id: string) => {
    await db.subChats.delete(id)
    // detach messages so they remain in the parent transcript
    const msgs = await db.messages.where("subChatId").equals(id).toArray()
    for (const m of msgs) await db.messages.update(m.id, { subChatId: undefined })
    if (activeSubChatId === id) setActiveSubChatId(null)
    refresh()
  }

  const rename = async (id: string, title: string) => {
    await db.subChats.update(id, { title, updatedAt: Date.now() })
    refresh()
  }

  const pin = async (id: string, pinned: boolean) => {
    await db.subChats.update(id, { pinned: pinned ? 1 : 0 })
    refresh()
  }

  const onDragOver = (e: React.DragEvent, id: string) => {
    e.preventDefault()
    if (!dragId.current || dragId.current === id) return
  }
  const onDrop = async (id: string) => {
    if (!dragId.current || dragId.current === id) return
    const a = subs.find((s) => s.id === dragId.current!)
    const b = subs.find((s) => s.id === id)
    if (!a || !b) return
    // swap orders
    await db.subChats.update(a.id, { order: b.order })
    await db.subChats.update(b.id, { order: a.order })
    dragId.current = null
    refresh()
  }

  if (!activeChatId) return null

  return (
    <div className="flex items-center gap-0.5 px-1 h-7 overflow-x-auto bg-al-panel/60 border-b border-border/60">
      <button
        onClick={() => setActiveSubChatId(null)}
        className={cn(
          "px-2 h-5 rounded text-[10px] flex items-center gap-1 transition shrink-0",
          activeSubChatId === null
            ? "bg-al-accent/25 text-foreground shadow-sm"
            : "text-muted-foreground hover:bg-accent/40"
        )}
        title="Main thread"
      >
        <AppIcon name="chat" width={10} /> Main
      </button>
      <AnimatePresence>
        {subs.map((s) => (
          <motion.div
            key={s.id}
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9 }}
            draggable
            onDragStart={() => { dragId.current = s.id }}
            onDragOver={(e) => onDragOver(e, s.id)}
            onDrop={() => onDrop(s.id)}
            className={cn(
              "group px-2 h-5 rounded text-[10px] flex items-center gap-1 transition shrink-0 cursor-pointer",
              activeSubChatId === s.id
                ? "bg-al-accent/25 text-foreground shadow-sm"
                : "text-muted-foreground hover:bg-accent/40"
            )}
            onClick={() => setActiveSubChatId(s.id)}
            onDoubleClick={() => setEditing(s.id)}
          >
            {s.pinned ? <span className="text-amber-400">★</span> : null}
            {editing === s.id ? (
              <input
                autoFocus
                defaultValue={s.title}
                onBlur={(e) => { rename(s.id, e.target.value); setEditing(null) }}
                onKeyDown={(e) => { if (e.key === "Enter") (e.target as HTMLInputElement).blur() }}
                className="bg-transparent outline-none w-20"
                onClick={(e) => e.stopPropagation()}
              />
            ) : (
              <span className="truncate max-w-[120px]">{s.title}</span>
            )}
            <button
              onClick={(e) => { e.stopPropagation(); pin(s.id, !s.pinned) }}
              className="opacity-0 group-hover:opacity-60 hover:opacity-100"
              title={s.pinned ? "Unpin" : "Pin"}
            >
              <AppIcon name={s.pinned ? "minus" : "plus"} width={9} />
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); remove(s.id) }}
              className="opacity-0 group-hover:opacity-60 hover:opacity-100 hover:text-destructive"
              title="Close tab"
            >
              <AppIcon name="close" width={9} />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
      <button
        onClick={create}
        className="px-1.5 h-5 rounded text-[10px] text-muted-foreground hover:bg-accent/40 shrink-0"
        title="New sub-chat tab"
      >
        <AppIcon name="plus" width={11} />
      </button>
    </div>
  )
}
