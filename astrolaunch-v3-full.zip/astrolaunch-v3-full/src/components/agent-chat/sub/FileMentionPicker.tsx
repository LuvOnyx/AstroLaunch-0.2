"use client"
/**
 * @-mentions popup for files. When the user types `@foo` in the input the
 * floating chat opens this picker; results come from the Dexie file table
 * with simple fuzzy matching (substring + token overlap score).
 */
import { useEffect, useState, useMemo } from "react"
import { db } from "@/lib/storage/db"
import type { FileNode } from "@/types"
import { FileIcon } from "@/lib/iconify"
import { cn } from "@/lib/utils"
import { motion, AnimatePresence } from "framer-motion"

interface Props {
  query: string
  onPick: (path: string) => void
  onClose: () => void
}

function score(needle: string, hay: string): number {
  if (!needle) return 1
  const n = needle.toLowerCase(), h = hay.toLowerCase()
  if (h === n) return 100
  if (h.includes(n)) return 50 + Math.max(0, 30 - h.length + n.length)
  // token overlap
  const tokens = n.split(/[/.\-_\s]/).filter(Boolean)
  let s = 0
  for (const t of tokens) if (h.includes(t)) s += 4
  return s
}

export function FileMentionPicker({ query, onPick, onClose }: Props) {
  const [files, setFiles] = useState<FileNode[]>([])
  const [hover, setHover] = useState(0)

  useEffect(() => {
    (async () => {
      if (!db) return
      const all = await db.files.where("type").equals("file").toArray()
      setFiles(all)
    })()
  }, [])

  const ranked = useMemo(() => {
    const q = query.replace(/^@/, "").trim()
    return files
      .map((f) => ({ f, s: score(q, f.path) }))
      .filter((x) => x.s > 0)
      .sort((a, b) => b.s - a.s)
      .slice(0, 8)
      .map((x) => x.f)
  }, [files, query])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowDown") { e.preventDefault(); setHover((h) => Math.min(h + 1, ranked.length - 1)) }
      else if (e.key === "ArrowUp") { e.preventDefault(); setHover((h) => Math.max(h - 1, 0)) }
      else if (e.key === "Enter" && ranked[hover]) { e.preventDefault(); onPick(ranked[hover].path) }
      else if (e.key === "Escape") onClose()
    }
    window.addEventListener("keydown", onKey, true)
    return () => window.removeEventListener("keydown", onKey, true)
  }, [hover, ranked, onPick, onClose])

  if (ranked.length === 0) return null
  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 4 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 4 }}
        className="absolute bottom-full mb-1 left-2 right-2 z-30 rounded-md border border-border bg-al-panel/95 backdrop-blur-md shadow-2xl overflow-hidden"
      >
        <div className="px-2 py-1 text-[10px] uppercase tracking-wider text-muted-foreground">
          Mention file
        </div>
        {ranked.map((f, i) => (
          <button
            key={f.id}
            onMouseEnter={() => setHover(i)}
            onClick={() => onPick(f.path)}
            className={cn(
              "w-full flex items-center gap-2 px-2 py-1 text-[11px] text-left",
              hover === i ? "bg-al-accent/20 text-foreground" : "text-muted-foreground hover:bg-accent/30"
            )}
          >
            <FileIcon filename={f.name} width={12} />
            <span className="truncate flex-1">{f.path}</span>
            <span className="opacity-50 text-[9px]">{(f.size ?? 0)}b</span>
          </button>
        ))}
      </motion.div>
    </AnimatePresence>
  )
}
