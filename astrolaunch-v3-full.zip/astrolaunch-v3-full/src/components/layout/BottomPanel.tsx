"use client"
/**
 * BottomPanel — v3.
 *
 * In v3 the BottomPanel is *always mounted* inside CenterPanel's vertical
 * split, so its height is owned by react-resizable-panels rather than the
 * legacy `bottomHeight` numeric state. The panel still respects
 * `showBottomPanel` for collapsing — when collapsed it just renders a thin
 * tab strip the user can click to expand.
 *
 * Tabs: terminal · problems · output · agent log.
 */
import { useWorkspace, type BottomPanelTab } from "@/store/workspace"
import { TerminalPanel } from "@/components/terminal/TerminalPanel"
import { Button } from "@/components/ui/button"
import { AppIcon } from "@/lib/iconify"
import { cn } from "@/lib/utils"
import { useEffect, useState } from "react"
import { db } from "@/lib/storage/db"

const TABS: { id: BottomPanelTab; label: string; icon: string }[] = [
  { id: "terminal", label: "Terminal",  icon: "terminal" },
  { id: "problems", label: "Problems",  icon: "warning"  },
  { id: "output",   label: "Output",    icon: "file"     },
  { id: "agent-log",label: "Agent log", icon: "agent"    },
]

export function BottomPanel() {
  const { showBottomPanel, bottomTab, setBottomTab, setShowBottomPanel } = useWorkspace()

  if (!showBottomPanel) {
    // Collapsed view: thin click strip
    return (
      <button
        onClick={() => setShowBottomPanel(true)}
        className="w-full h-full flex items-center gap-2 px-3 text-[11px] text-muted-foreground border-t border-border bg-al-panel/60 hover:bg-al-panel"
      >
        <AppIcon name="terminal" width={12} className="text-al-accent" />
        Terminal hidden — click to expand
      </button>
    )
  }

  return (
    <div className="h-full border-t border-border bg-al-panel flex flex-col">
      <div className="h-8 flex items-center px-2 gap-1 border-b border-border bg-al-panel/80 backdrop-blur-sm">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setBottomTab(t.id)}
            className={cn(
              "px-2 py-0.5 rounded text-[11px] flex items-center gap-1 transition",
              bottomTab === t.id ? "bg-al-accent/25 text-foreground" : "text-muted-foreground hover:bg-accent/30"
            )}
          >
            <AppIcon name={t.icon} width={11} />
            {t.label}
          </button>
        ))}
        <Button size="icon-sm" variant="ghost" className="ml-auto" onClick={() => setShowBottomPanel(false)} title="Hide panel">
          <AppIcon name="close" width={13} />
        </Button>
      </div>
      <div className="flex-1 min-h-0">
        {bottomTab === "terminal"  && <TerminalPanel />}
        {bottomTab === "problems"  && <ProblemsView />}
        {bottomTab === "output"    && <OutputView />}
        {bottomTab === "agent-log" && <AgentLogView />}
      </div>
    </div>
  )
}

function ProblemsView() {
  const [items, setItems] = useState<{ path: string; size: number }[]>([])
  useEffect(() => {
    (async () => {
      if (!db) return
      const all = await db.files.where("agentTouched").equals(1).toArray()
      setItems(all.map((f) => ({ path: f.path, size: f.size ?? 0 })))
    })()
  }, [])
  return (
    <div className="p-3 text-xs text-muted-foreground space-y-1">
      <div>0 problems · diagnostics from typecheck/lint will surface here.</div>
      {items.length > 0 && (
        <div className="pt-2">
          <div className="text-[10px] uppercase tracking-wider">Agent-touched files</div>
          {items.map((i) => <div key={i.path} className="font-mono text-[11px]">{i.path}</div>)}
        </div>
      )}
    </div>
  )
}

function OutputView() {
  const [lines, setLines] = useState<string[]>([])
  useEffect(() => {
    if (typeof window === "undefined") return
    const wc = (window as unknown as { alWebContainer?: { onOutput?: (cb: (s: string) => void) => () => void } }).alWebContainer
    if (!wc?.onOutput) return
    return wc.onOutput((chunk) => {
      setLines((prev) => [...prev.slice(-400), ...chunk.split("\n")].slice(-400))
    })
  }, [])
  return (
    <div className="h-full overflow-auto p-2 font-mono text-[11px] text-muted-foreground whitespace-pre-wrap">
      {lines.length === 0 ? "(no output yet — start a process from the terminal or Run preview)" : lines.join("\n")}
    </div>
  )
}

function AgentLogView() {
  const [lines, setLines] = useState<string[]>([])
  useEffect(() => {
    const onLog = (e: Event) => {
      const ce = e as CustomEvent<string>
      setLines((prev) => [...prev.slice(-200), ce.detail])
    }
    window.addEventListener("astrolaunch:agent-log", onLog as EventListener)
    return () => window.removeEventListener("astrolaunch:agent-log", onLog as EventListener)
  }, [])
  return (
    <div className="h-full overflow-auto p-2 font-mono text-[11px] text-muted-foreground whitespace-pre-wrap">
      {lines.length === 0 ? "(idle — agent events will appear here once /build runs)" : lines.join("\n")}
    </div>
  )
}
