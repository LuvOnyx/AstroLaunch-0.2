"use client"
/**
 * CenterPanel — v3 layout.
 *
 * Phase-2 layout requirements:
 *   - Terminal stays where it is (BottomPanel — collapsible)
 *   - Live Preview sits ABOVE the terminal as its own column
 *   - Editor sits to the RIGHT of the live preview
 *   - The Penpot/fallback design panel swaps with the live preview
 *     in the same column (toggle via topbar pills, /design, or the
 *     in-column swap button).
 *
 * So the visual layout becomes:
 *
 *   ┌─────────────┬───────────────────────────┐
 *   │             │                           │
 *   │  Preview /  │           Editor          │
 *   │  Design     │                           │
 *   │   column    │                           │
 *   │             │                           │
 *   ├─────────────┴───────────────────────────┤
 *   │              Terminal panel             │
 *   └─────────────────────────────────────────┘
 */
import { useWorkspace } from "@/store/workspace"
import { CodeEditor } from "@/components/editor/CodeEditor"
import { PreviewPanel } from "@/components/preview/PreviewPanel"
import { DesignPanel } from "@/components/canvas/DesignPanel"
import { PluginRunner } from "@/components/plugins/PluginRunner"
import { BottomPanel } from "@/components/layout/BottomPanel"
import { Panel, PanelGroup, PanelResizeHandle } from "react-resizable-panels"
import { Button } from "@/components/ui/button"
import { AppIcon } from "@/lib/iconify"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"

interface Props { running: boolean }

export function CenterPanel({ running }: Props) {
  const { activePluginId, designMode, setDesignMode } = useWorkspace()

  return (
    <div className="h-full flex flex-col">
      <PanelGroup direction="vertical" className="flex-1 min-h-0">
        {/* Top split: [Preview/Design column | Editor column] */}
        <Panel defaultSize={62} minSize={28} id="top">
          {activePluginId ? (
            <PluginRunner />
          ) : (
            <PanelGroup direction="horizontal" className="h-full">
              <Panel defaultSize={48} minSize={20} id="design-or-preview">
                <DesignPreviewColumn running={running} designMode={designMode} setDesignMode={setDesignMode} />
              </Panel>
              <PanelResizeHandle className="w-1 bg-border hover:bg-al-accent transition" />
              <Panel defaultSize={52} minSize={28} id="editor-column">
                <CodeEditor />
              </Panel>
            </PanelGroup>
          )}
        </Panel>
        <PanelResizeHandle className="h-1 bg-border hover:bg-al-accent transition" />
        {/* Bottom slot reserved for the terminal / output / agent log etc. */}
        <Panel defaultSize={38} minSize={10} id="bottom">
          <BottomPanel />
        </Panel>
      </PanelGroup>
    </div>
  )
}

/**
 * The left column hosts either the live preview or the design (Penpot /
 * fallback) surface — toggled with a glassy two-pill switch at the top.
 */
function DesignPreviewColumn({
  running, designMode, setDesignMode,
}: {
  running: boolean
  designMode: "preview" | "design"
  setDesignMode: (m: "preview" | "design") => void
}) {
  return (
    <div className="h-full flex flex-col bg-al-canvas">
      <div className="h-7 px-2 flex items-center gap-1 border-b border-border/60 bg-al-panel/70 backdrop-blur-sm">
        <div className="flex bg-background/40 rounded-md p-0.5 border border-border/40 text-[10px]">
          {(["preview", "design"] as const).map((m) => (
            <button
              key={m}
              onClick={() => setDesignMode(m)}
              className={cn(
                "px-2 py-0.5 rounded flex items-center gap-1 transition",
                designMode === m ? "bg-al-accent/30 text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
              )}
              title={m === "preview" ? "Live preview" : "Design canvas"}
            >
              <AppIcon name={m === "preview" ? "preview" : "canvas"} width={11} />
              {m === "preview" ? "Preview" : "Design"}
            </button>
          ))}
        </div>
        <span className="ml-auto text-[10px] text-muted-foreground">
          {designMode === "preview"
            ? running ? "live" : "press Run"
            : "Penpot / Fast Canvas"}
        </span>
        <Button
          size="icon-sm"
          variant="ghost"
          onClick={() => setDesignMode(designMode === "preview" ? "design" : "preview")}
          title="Swap (⌘⇧D)"
        >
          <AppIcon name="diff" width={12} />
        </Button>
      </div>
      <div className="flex-1 min-h-0 relative">
        <AnimatePresence mode="wait">
          {designMode === "preview" ? (
            <motion.div
              key="preview"
              initial={{ opacity: 0, scale: 0.99 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.18 }}
              className="absolute inset-0"
            >
              <PreviewPanel running={running} />
            </motion.div>
          ) : (
            <motion.div
              key="design"
              initial={{ opacity: 0, scale: 0.99 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.18 }}
              className="absolute inset-0"
            >
              <DesignPanel />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}
