"use client"
/**
 * Penpot bridge — v3.
 *
 * Penpot is integrated three different ways, in order of preference:
 *
 *  1. **Embedded iframe** (default) — points at a self-hosted or cloud Penpot
 *     instance. We use the official `?embed=true` flag and add postMessage
 *     hooks for two-way comms, matching the protocol used by Penpot's
 *     plugin SDK runtime.
 *
 *  2. **Penpot Plugin runtime** — when AstroLaunch is loaded *inside* a Penpot
 *     plugin shell, `window.penpot` is exposed. The bridge transparently uses
 *     it instead of postMessage so design tokens and SVG export round-trip
 *     through Penpot's official API surface (no CSP friction).
 *
 *  3. **Fallback canvas** — if the user has no Penpot connection at all the
 *     `<DesignPanel/>` mounts a tldraw-style SVG canvas as the "next best
 *     thing", governed by `lib/canvas/fallback.ts`.
 *
 * The bridge speaks the same `{type, payload, source}` protocol regardless of
 * transport, so consumers (DesignPanel, agents, etc.) don't care which one is
 * active at any given moment.
 */

import type { DesignToken, DesignFrame } from "@/types"

export interface PenpotConfig {
  baseUrl: string
  fileId?: string
  pageId?: string
  accessToken?: string
  /** Force CSS theme inside the embedded canvas. */
  theme?: "dark" | "light" | "system"
}

export interface PenpotMessage {
  type: string
  payload?: unknown
  source?: string
  /** Correlate request → response across postMessage. */
  requestId?: string
}

declare global {
  interface Window {
    /** Exposed when AstroLaunch runs as a Penpot plugin. */
    penpot?: {
      ui?: {
        sendMessage: (msg: unknown) => void
        onMessage: (cb: (msg: unknown) => void) => () => void
      }
      currentFile?: () => Promise<{ id: string; pages: { id: string; name: string }[] }>
      exportFrame?: (id: string, format: "svg" | "png") => Promise<string>
      listTokens?: () => Promise<DesignToken[]>
    }
  }
}

export const DEFAULT_PENPOT_URL = "https://design.penpot.app"

const REQ_TIMEOUT = 6000

export class PenpotBridge {
  private iframe: HTMLIFrameElement | null = null
  private listeners = new Map<string, Set<(p: unknown) => void>>()
  private pending = new Map<string, (val: unknown) => void>()
  private config: PenpotConfig

  constructor(config: PenpotConfig) {
    this.config = config
    if (typeof window !== "undefined") {
      window.addEventListener("message", this.handleMessage)
    }
  }

  /** Whether we're running *inside* a Penpot plugin (window.penpot present). */
  get isPluginRuntime() {
    return typeof window !== "undefined" && !!window.penpot
  }

  attach(iframe: HTMLIFrameElement) {
    this.iframe = iframe
    // Push initial handshake once the iframe loads.
    iframe.addEventListener("load", this.handshake, { once: true })
  }

  detach() {
    this.iframe = null
    this.listeners.clear()
    this.pending.clear()
    if (typeof window !== "undefined") window.removeEventListener("message", this.handleMessage)
  }

  buildEmbedUrl() {
    const { baseUrl, fileId, pageId, theme } = this.config
    const base = baseUrl.replace(/\/$/, "")
    const url = new URL(`${base}/`)
    if (fileId) {
      url.hash = `/workspace/${fileId}${pageId ? `?page-id=${encodeURIComponent(pageId)}` : ""}`
    } else {
      url.hash = `/`
    }
    url.searchParams.set("embed", "true")
    if (theme) url.searchParams.set("theme", theme)
    return url.toString()
  }

  /** Subscribe to bridge events. Returns unsubscribe. */
  on(type: string, fn: (p: unknown) => void) {
    if (!this.listeners.has(type)) this.listeners.set(type, new Set())
    this.listeners.get(type)!.add(fn)
    return () => this.listeners.get(type)?.delete(fn)
  }

  /** Fire-and-forget message. */
  send(type: string, payload?: unknown) {
    if (this.isPluginRuntime) {
      window.penpot?.ui?.sendMessage({ type, payload, source: "astrolaunch" })
      return
    }
    if (!this.iframe?.contentWindow) return
    this.iframe.contentWindow.postMessage({ type, payload, source: "astrolaunch" }, "*")
  }

  /** Request → response with a generated id, resolving on matching `${type}_result`. */
  async request<T = unknown>(type: string, payload?: unknown): Promise<T | null> {
    const requestId = `req_${Math.random().toString(36).slice(2, 10)}`
    return new Promise((resolve) => {
      const timer = setTimeout(() => {
        this.pending.delete(requestId)
        resolve(null)
      }, REQ_TIMEOUT)
      this.pending.set(requestId, (val) => { clearTimeout(timer); resolve(val as T) })
      const wrapped = { type, payload, source: "astrolaunch", requestId }
      if (this.isPluginRuntime) window.penpot?.ui?.sendMessage(wrapped)
      else this.iframe?.contentWindow?.postMessage(wrapped, "*")
    })
  }

  private handshake = () => {
    this.send("astrolaunch:handshake", { version: 3, theme: this.config.theme ?? "dark" })
  }

  private handleMessage = (e: MessageEvent) => {
    if (typeof e.data !== "object" || !e.data) return
    const msg = e.data as PenpotMessage
    if (!msg.type) return
    // Resolve correlated request, if any.
    if (msg.requestId && this.pending.has(msg.requestId)) {
      const resolver = this.pending.get(msg.requestId)!
      this.pending.delete(msg.requestId)
      resolver(msg.payload)
    }
    const set = this.listeners.get(msg.type)
    set?.forEach((fn) => { try { fn(msg.payload) } catch {} })
  }

  /* ---------- High-level convenience methods ---------- */

  async exportFrameSvg(frameId: string): Promise<DesignFrame | null> {
    if (this.isPluginRuntime && window.penpot?.exportFrame) {
      const svg = await window.penpot.exportFrame(frameId, "svg")
      if (!svg) return null
      return { id: frameId, name: frameId, svg, capturedAt: Date.now() }
    }
    const res = await this.request<{ frameId: string; name?: string; svg: string; width?: number; height?: number }>("request-export-svg", { frameId })
    if (!res?.svg) return null
    return {
      id: res.frameId, name: res.name ?? res.frameId, svg: res.svg,
      width: res.width, height: res.height, capturedAt: Date.now(),
    }
  }

  async listTokens(): Promise<DesignToken[]> {
    if (this.isPluginRuntime && window.penpot?.listTokens) {
      const tokens = await window.penpot.listTokens()
      return tokens ?? []
    }
    const tokens = await this.request<DesignToken[]>("request-tokens")
    return Array.isArray(tokens) ? tokens : []
  }

  async listFrames(): Promise<{ id: string; name: string }[]> {
    const frames = await this.request<{ frames: { id: string; name: string }[] }>("request-frames")
    return frames?.frames ?? []
  }

  /** Convert tokens to a CSS variable block. */
  tokensToCss(tokens: DesignToken[]): string {
    const lines = [":root {"]
    for (const t of tokens) {
      const name = `--${(t.group ? `${t.group}-` : "") + t.name}`.replace(/[^a-zA-Z0-9-]/g, "-").toLowerCase()
      lines.push(`  ${name}: ${t.value};`)
    }
    lines.push("}")
    return lines.join("\n")
  }
}
