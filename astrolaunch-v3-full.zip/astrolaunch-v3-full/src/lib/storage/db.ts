"use client"
import Dexie, { Table } from "dexie"
import type {
  FileNode, AgentChat, AgentMessage, AgentTask, ProjectMeta, AgentPersona,
  PluginRecord, TerminalSession, UsageRow,
  SubChat, QueuedMessage, DesignToken, DesignFrame,
} from "@/types"

class AstroDB extends Dexie {
  files!: Table<FileNode, string>
  chats!: Table<AgentChat, string>
  messages!: Table<AgentMessage, string>
  tasks!: Table<AgentTask, string>
  projects!: Table<ProjectMeta, string>
  personas!: Table<AgentPersona, string>
  plugins!: Table<PluginRecord, string>
  terminals!: Table<TerminalSession, string>
  usage!: Table<UsageRow, string>
  // v3
  subChats!: Table<SubChat, string>
  queue!: Table<QueuedMessage, string>
  designTokens!: Table<DesignToken, string>
  designFrames!: Table<DesignFrame, string>

  constructor() {
    super("astrolaunch-db")
    this.version(1).stores({
      files: "id, parentId, path, type",
      chats: "id, agentId, updatedAt, archived",
      messages: "id, chatId, createdAt, taskId",
      tasks: "id, chatId, parentTaskId, status, is_done, updatedAt",
      projects: "id, name, createdAt",
      personas: "id, name",
    })
    this.version(2).stores({
      files: "id, parentId, path, type, agentTouched",
      chats: "id, agentId, updatedAt, archived",
      messages: "id, chatId, createdAt, taskId, personaId",
      tasks: "id, chatId, parentTaskId, status, is_done, updatedAt",
      projects: "id, name, createdAt",
      personas: "id, name",
      plugins: "id, name, enabled, installedAt",
      terminals: "id, createdAt",
      usage: "id, chatId, taskId, model, ts",
    }).upgrade(async () => {})
    // v3 — sub-chats, message queue, design tokens & frames
    this.version(3).stores({
      files: "id, parentId, path, type, agentTouched",
      chats: "id, agentId, updatedAt, archived, parentChatId",
      messages: "id, chatId, subChatId, createdAt, taskId, personaId",
      tasks: "id, chatId, parentTaskId, status, is_done, updatedAt",
      projects: "id, name, createdAt",
      personas: "id, name",
      plugins: "id, name, enabled, installedAt",
      terminals: "id, createdAt",
      usage: "id, chatId, taskId, model, ts",
      subChats: "id, chatId, order, updatedAt, pinned",
      queue: "id, chatId, subChatId, createdAt",
      designTokens: "id, kind, source, updatedAt",
      designFrames: "id, name, capturedAt",
    }).upgrade(async () => {})
  }
}

export const db = typeof window !== "undefined" ? new AstroDB() : (null as unknown as AstroDB)
