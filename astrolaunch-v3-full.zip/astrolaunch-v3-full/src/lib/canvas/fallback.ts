"use client"
/**
 * Fallback design canvas — used when no Penpot instance is configured.
 *
 * This is a tiny vector editor written in plain SVG/React (no external
 * dependencies) so it always works offline and ships zero extra weight.
 * It implements the *minimum useful subset* of a Figma-like canvas:
 *
 *   - rectangles, ellipses, frames, text and free-hand pen paths
 *   - selection + drag + scale handles
 *   - z-ordering (forward / back)
 *   - color, stroke, radius properties
 *   - serialize / deserialize JSON for storage
 *   - export to SVG
 *
 * It speaks the same {DesignFrame, DesignToken} types as the Penpot bridge,
 * so the rest of the app (DesignPanel, design tokens panel, agents) treats
 * both surfaces the same.
 */

import type { DesignFrame, DesignToken } from "@/types"
import { nanoid } from "nanoid"

export type ShapeKind = "rect" | "ellipse" | "frame" | "text" | "path"

export interface CanvasShape {
  id: string
  kind: ShapeKind
  x: number
  y: number
  w: number
  h: number
  rotation?: number
  fill?: string
  stroke?: string
  strokeWidth?: number
  radius?: number
  text?: string
  fontSize?: number
  fontFamily?: string
  /** SVG path "d" attribute for kind="path". */
  d?: string
  z?: number
}

export interface CanvasDoc {
  id: string
  name: string
  width: number
  height: number
  background: string
  shapes: CanvasShape[]
  tokens: DesignToken[]
  updatedAt: number
}

export const DEFAULT_DOC: CanvasDoc = {
  id: "default",
  name: "Untitled",
  width: 1440,
  height: 900,
  background: "#0c0c10",
  shapes: [],
  tokens: [],
  updatedAt: Date.now(),
}

export function makeShape(partial: Partial<CanvasShape> & { kind: ShapeKind }): CanvasShape {
  return {
    id: nanoid(8),
    x: 80,
    y: 80,
    w: 200,
    h: 120,
    fill: "#a78bfa",
    stroke: "transparent",
    strokeWidth: 0,
    radius: 12,
    fontSize: 16,
    fontFamily: "Inter, system-ui, sans-serif",
    text: partial.kind === "text" ? "Text" : undefined,
    ...partial,
  }
}

export function exportSvg(doc: CanvasDoc): string {
  const sorted = [...doc.shapes].sort((a, b) => (a.z ?? 0) - (b.z ?? 0))
  const parts: string[] = []
  parts.push(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${doc.width}" height="${doc.height}" viewBox="0 0 ${doc.width} ${doc.height}">`,
    `<rect width="${doc.width}" height="${doc.height}" fill="${escape(doc.background)}"/>`
  )
  for (const s of sorted) {
    const tx = s.rotation ? ` transform="rotate(${s.rotation} ${s.x + s.w / 2} ${s.y + s.h / 2})"` : ""
    if (s.kind === "rect" || s.kind === "frame") {
      parts.push(`<rect x="${s.x}" y="${s.y}" width="${s.w}" height="${s.h}" rx="${s.radius ?? 0}" fill="${escape(s.fill ?? "transparent")}" stroke="${escape(s.stroke ?? "transparent")}" stroke-width="${s.strokeWidth ?? 0}"${tx}/>`)
    } else if (s.kind === "ellipse") {
      parts.push(`<ellipse cx="${s.x + s.w / 2}" cy="${s.y + s.h / 2}" rx="${s.w / 2}" ry="${s.h / 2}" fill="${escape(s.fill ?? "transparent")}" stroke="${escape(s.stroke ?? "transparent")}" stroke-width="${s.strokeWidth ?? 0}"${tx}/>`)
    } else if (s.kind === "text") {
      parts.push(`<text x="${s.x}" y="${s.y + (s.fontSize ?? 16)}" font-family="${escape(s.fontFamily ?? "Inter, sans-serif")}" font-size="${s.fontSize ?? 16}" fill="${escape(s.fill ?? "#fff")}"${tx}>${escapeText(s.text ?? "")}</text>`)
    } else if (s.kind === "path" && s.d) {
      parts.push(`<path d="${escape(s.d)}" fill="${escape(s.fill ?? "transparent")}" stroke="${escape(s.stroke ?? "currentColor")}" stroke-width="${s.strokeWidth ?? 1.5}"${tx}/>`)
    }
  }
  parts.push("</svg>")
  return parts.join("\n")
}

export function frameFromDoc(doc: CanvasDoc): DesignFrame {
  return {
    id: doc.id, name: doc.name, svg: exportSvg(doc),
    width: doc.width, height: doc.height, capturedAt: Date.now(),
  }
}

function escape(s: string) { return s.replace(/"/g, "&quot;").replace(/</g, "&lt;") }
function escapeText(s: string) { return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;") }
