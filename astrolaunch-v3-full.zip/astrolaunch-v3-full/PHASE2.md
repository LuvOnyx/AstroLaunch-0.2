# AstroLaunch v0.3 — Phase 2 Release Notes

Phase 2 brings the **agent chat experience from `21st-dev/1code`** and the
**real Penpot design canvas** into AstroLaunch, plus a major layout
refactor and a global UI polish pass.

---

## 1. Layout — terminal stays, preview floats up, editor goes right

The center workspace now matches the spec exactly:

```
┌──────────────────────┬──────────────────────────┐
│  Preview / Design    │          Editor          │
│      column          │                          │
├──────────────────────┴──────────────────────────┤
│                  Terminal panel                  │
└──────────────────────────────────────────────────┘
```

- `CenterPanel` switched from a vertical `[editor / preview]` split to a
  horizontal `[preview-or-design | editor]` row, with the terminal anchored
  beneath it via a single bottom panel (`react-resizable-panels`).
- The bottom panel is owned by the resize group instead of a popup — pulling
  the divider down hides it; clicking the collapsed strip restores it.
- A new in-column **Preview ↔ Design** pill switch (and the topbar pills)
  toggles between the live preview and the design canvas without losing
  state on either side.

## 2. Real Penpot canvas

`PenpotCanvas` was rewritten around an upgraded bridge:

- `PenpotBridge` v3 implements the Penpot postMessage protocol with
  `{type, payload, source, requestId}` envelopes, request/response
  correlation, a 6 s timeout, and **transparent fallback to
  `window.penpot`** when AstroLaunch is loaded as a Penpot plugin.
- The panel ships a **3-mode connection wizard** (cloud, self-host, plugin),
  a live connection-state indicator, and toolbar buttons for **token sync**
  and **frame export** (round-tripped via the bridge).
- A bundled **`docker/penpot/docker-compose.yml`** brings up the official
  Penpot stack (frontend, backend, exporter, Postgres, Redis) with
  `enable-design-tokens` and `enable-plugins` set, so self-hosting is a
  one-command affair: `npm run penpot:up`.
- When no Penpot file is configured the panel mounts a self-contained
  `FallbackCanvas` — a real SVG editor with select / rect / ellipse / frame /
  text tools, 8-handle resize, fill / stroke / radius / rotation
  inspector, copy / duplicate / delete, and SVG export. This is the
  documented "next best thing" path; everything still funnels through the
  same `DesignFrame` + `DesignToken` types so agents don't notice the swap.

## 3. Agent chat — 1code-grade

`FloatingAgentChat` was rebuilt around the patterns the user called out:

- **Sub-chat tab strip** (`SubChatTabs`) — per-chat tabs with drag-to-reorder
  and pinning, matching `features/sub-chats` from 1code.
- **Slash command palette** (`SlashCommandPalette`) — `/plan`, `/build`,
  `/agent`, `/fork`, `/clear`, `/queue`, `/run`, `/design`, `/tokens`,
  `/export`, `/rollback`. Activates on `/`, navigable with arrow keys.
- **File mentions** (`FileMentionPicker`) — `@path` opens a fuzzy file
  picker and the chat ships the mentioned files as system context.
- **Plan mode** (`PlanCard`) — `/plan <goal>` produces a structured,
  reorderable plan card with editable doneCriteria and explicit
  Approve & Run; only then does the orchestrator execute.
- **Message queue** (`MessageQueue`) — keep typing while the agent is busy;
  prompts park in IndexedDB and drain in order when the agent goes idle.
- **Per-message toolbar** — copy / fork / rollback on hover. Forking copies
  history up to the source message into a new chat with a `↗` badge in
  the connected sidebar.
- **Connected agent sidebar** (`AgentChatList`) — search, active / archived
  / forks filters, persona quick-spawn grid with brand colors, hover
  actions for archive / duplicate / delete, and a per-chat cost chip.

## 4. UI polish

- Refined dark palette (cooler darks, richer accent, two extra accent
  channels), gradient logo chip, glassy floating-window styling.
- New utility classes: `al-glass`, `al-chip-gradient`, `al-thinking`,
  `al-live` for consistent depth and motion.
- Topbar got the gradient brand chip, refined pill switch, monospace
  cost badge, and `Tooltip` polish across the app.

## 5. Persistence layer

- Dexie schema bumped to **v3** with `subChats`, `queue`, `designTokens`,
  `designFrames` tables; existing v2 data migrates cleanly.
- New domain types: `SubChat`, `QueuedMessage`, `DesignToken`, `DesignFrame`,
  `PlanStepView`. `AgentChat` gained `parentChatId`, `forkedFromMessageId`
  and `color`. `AgentMessage` gained `subChatId`, `plan`, `mentions` and
  `forkPoint`.

## 6. Slash command bus

A small custom-event bus lets the chat reach the rest of the app
without importing it directly:

| Event                                   | Origin                 | Sink                                  |
| --------------------------------------- | ---------------------- | ------------------------------------- |
| `astrolaunch:request-tokens`            | `/tokens`              | `PenpotCanvas` → bridge.listTokens    |
| `astrolaunch:export-frame`              | `/export`              | `PenpotCanvas` → bridge.exportFrame   |
| `astrolaunch:rollback`                  | `/rollback`            | (consumer hook, opt-in)               |
| `astrolaunch:run-shell`                 | `/run <cmd>`           | terminal panel                        |
| `astrolaunch:terminal-paste`            | page → terminal        | xterm shell.write                     |
| `astrolaunch:penpot-config`             | `PenpotCanvas` save    | `DesignPanel` (swap surface)          |

## 7. Backwards compatibility

- v2 IndexedDB stores upgrade in place; no data is deleted.
- Settings and workspace persistence keys move from `…workspace.v2` to
  `…workspace.v3`; old keys are ignored, defaults are conservative.
- All v2 components unchanged outside of the files listed in the patch
  manifest.

---

**Files added or rewritten in this patch:**

```
src/types/index.ts                                         (rewritten)
src/store/workspace.ts                                     (rewritten)
src/lib/storage/db.ts                                      (rewritten)
src/lib/penpot/bridge.ts                                   (rewritten)
src/lib/canvas/fallback.ts                                 (new)
src/components/canvas/PenpotCanvas.tsx                     (rewritten)
src/components/canvas/FallbackCanvas.tsx                   (new)
src/components/canvas/DesignPanel.tsx                      (new)
src/components/agent-chat/FloatingAgentChat.tsx            (rewritten)
src/components/agent-chat/AgentChatList.tsx                (rewritten)
src/components/agent-chat/MessageView.tsx                  (rewritten)
src/components/agent-chat/sub/SubChatTabs.tsx              (new)
src/components/agent-chat/sub/MessageQueue.tsx             (new)
src/components/agent-chat/sub/PlanCard.tsx                 (new)
src/components/agent-chat/sub/FileMentionPicker.tsx        (new)
src/components/agent-chat/sub/SlashCommandPalette.tsx      (new)
src/components/layout/CenterPanel.tsx                      (rewritten)
src/components/layout/BottomPanel.tsx                      (rewritten)
src/components/topbar/Topbar.tsx                           (rewritten)
src/components/preview/PreviewPanel.tsx                    (rewritten)
src/app/page.tsx                                           (rewritten)
src/app/globals.css                                        (rewritten)
tailwind.config.ts                                         (rewritten)
package.json                                               (bumped to 0.3.0 + penpot scripts)
docker/penpot/docker-compose.yml                           (new)
docker/penpot/README.md                                    (new)
PHASE2.md                                                  (this file)
```
