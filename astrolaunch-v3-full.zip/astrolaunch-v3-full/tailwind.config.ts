import type { Config } from "tailwindcss"

const config: Config = {
  darkMode: ["class"],
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    container: { center: true, padding: "2rem", screens: { "2xl": "1400px" } },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: { DEFAULT: "hsl(var(--primary))", foreground: "hsl(var(--primary-foreground))" },
        secondary: { DEFAULT: "hsl(var(--secondary))", foreground: "hsl(var(--secondary-foreground))" },
        destructive: { DEFAULT: "hsl(var(--destructive))", foreground: "hsl(var(--destructive-foreground))" },
        muted: { DEFAULT: "hsl(var(--muted))", foreground: "hsl(var(--muted-foreground))" },
        accent: { DEFAULT: "hsl(var(--accent))", foreground: "hsl(var(--accent-foreground))" },
        popover: { DEFAULT: "hsl(var(--popover))", foreground: "hsl(var(--popover-foreground))" },
        card: { DEFAULT: "hsl(var(--card))", foreground: "hsl(var(--card-foreground))" },
        // AstroLaunch surfaces
        "al-topbar":  "hsl(var(--al-topbar))",
        "al-sidebar": "hsl(var(--al-sidebar))",
        "al-panel":   "hsl(var(--al-panel))",
        "al-canvas":  "hsl(var(--al-canvas))",
        "al-chat":    "hsl(var(--al-chat))",
        "al-accent":  "hsl(var(--al-accent))",
        "al-accent-2":"hsl(var(--al-accent-2))",
        "al-accent-3":"hsl(var(--al-accent-3))",
      },
      borderRadius: { lg: "var(--radius)", md: "calc(var(--radius) - 2px)", sm: "calc(var(--radius) - 4px)" },
      fontFamily: {
        sans: ["var(--font-sans)", "Inter", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "JetBrains Mono", "Menlo", "monospace"],
      },
      keyframes: {
        "accordion-down": { from: { height: "0" }, to: { height: "var(--radix-accordion-content-height)" } },
        "accordion-up": { from: { height: "var(--radix-accordion-content-height)" }, to: { height: "0" } },
        shimmer: { "100%": { transform: "translateX(100%)" } },
        "al-fade-in": { from: { opacity: "0", transform: "translateY(4px)" }, to: { opacity: "1", transform: "translateY(0)" } },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        shimmer: "shimmer 2s infinite",
        "al-fade-in": "al-fade-in 0.18s ease-out",
      },
      backgroundImage: {
        "al-brand": "linear-gradient(135deg, hsl(var(--al-accent)) 0%, hsl(var(--al-accent-3)) 50%, hsl(var(--al-accent-2)) 100%)",
        "al-panel-tilt": "linear-gradient(180deg, hsl(var(--al-panel) / 0.85), hsl(var(--al-panel) / 0.65))",
      },
      boxShadow: {
        "al-glow": "0 0 0 1px hsl(var(--al-accent) / 0.25), 0 8px 24px -8px hsl(var(--al-accent) / 0.4)",
        "al-card": "0 1px 0 hsl(0 0% 100% / 0.04) inset, 0 8px 24px -12px hsl(0 0% 0% / 0.5)",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}
export default config
