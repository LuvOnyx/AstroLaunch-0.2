# Self-hosted Penpot for AstroLaunch

This folder contains a one-command Docker bundle that brings up the **real,
upstream Penpot** stack (frontend + backend + exporter + Postgres + Redis)
ready to be embedded by AstroLaunch's Design panel.

## Bring it up

```bash
cd docker/penpot
docker compose up -d
```

Default URL: <http://localhost:9001>.

On first launch you'll be prompted to sign up — use any email/password,
verification is disabled in the bundled config so you can log in immediately.

## Wire it into AstroLaunch

1. Open the **Design** column → click the gear icon.
2. Switch the connection mode to **Self-host**.
3. Paste `http://localhost:9001` into *Penpot URL*.
4. Open any file in Penpot, copy the UUID from the URL after `/workspace/`,
   paste it into *File ID*.
5. Click **Connect canvas** — the iframe loads and the bridge handshakes.

You can now run `/tokens` and `/export` from the agent chat to round-trip
design tokens and frame SVGs into your codebase.

## Notes

- The bundle enables `enable-design-tokens` and `enable-plugins`, which are
  required by AstroLaunch's `PenpotBridge` for token sync and frame export.
- Assets are persisted to a Docker volume (`penpot_assets`); the database
  lives in `penpot_postgres`. Both survive `docker compose down`.
- For production use replace the demo credentials and front the stack with
  HTTPS (Caddy or NGINX) — see <https://help.penpot.app/technical-guide/getting-started/docker/>.
